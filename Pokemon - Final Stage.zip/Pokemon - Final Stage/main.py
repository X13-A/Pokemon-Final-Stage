import pygame
import sys
import pytmx
import random
from os import path
from settings import *
from sprites import *
import time


#on creer une classe "Game" pour mieux s'organiser et choisir quelle partie du code actualiser.
class Game:
    def __init__(self):
        pygame.init()
        self.clock = pygame.time.Clock()
        self.load_data()
        
        
    def load_data(self):
        self.map_folder = path.join(ressources_folder, 'maps')

        self.map_home = TiledMap(path.join(self.map_folder, 'home.tmx'))     
        self.map_starter_zone = TiledMap(path.join(self.map_folder, 'starter_zone.tmx'))     
        self.map_starter_cave = TiledMap(path.join(self.map_folder, 'starter_cave.tmx'))     
        self.map_boss_room = TiledMap(path.join(self.map_folder, 'boss_room.tmx')) 
        self.map_way_out = TiledMap(path.join(self.map_folder, 'way_out.tmx')) 
        self.map_balconi = TiledMap(path.join(self.map_folder, 'balconi.tmx'))        
        self.map_background1 = TiledMap(path.join(self.map_folder, 'background1.tmx')) 
        
        self.level = 'home'
        self.player_level = 1
        self.player_mana_regen = 0.1
        self.player_health_regen = 0.2
        self.player_max_health = 200
        self.player_max_mana = 100
        self.player_strength = 5
        self.player_xp = 0
        self.level_xp = 100
        self.player_vehicle = 'none'
        self.player_copper_coins = 0
        self.player_silver_coins = 0
        self.player_gold_coins = 0
        self.player_location = 1
        self.player_direction = walkDown[1]
        self.peacefull = True
        self.isfog = False
        self.fog = pygame.Surface((WIDTH, HEIGHT))        
        self.fog_color = BLACK
        self.music_volume = 0.5
        self.music_muted = False
        self.is_background = False
        self.loading = False

    def fadeout(self, width, height): 
        fade = pygame.Surface((width, height))
        fade.fill((0,0,0))
        for alpha in range(0, 100):
            fade.set_alpha(alpha * 6)
            self.draw()
            screen.blit(fade, (0,0))
            pygame.display.update()
            self.music.set_volume(self.music_volume - alpha /100)
            if alpha <= 100:
                self.loading = True
                
    def new_game(self):      
        self.menu_count = 0        
        self.menu_open = False
        self.player_freeze = False      
        self.boss_defeated = False
        self.flashing = False
            
        self.time_multiplier = 1
        self.time_multiplier_100 = 100
        self.time_wait = 0 
        
        self.flash_alpha = 300
        self.flash = pygame.Surface((WIDTH, HEIGHT))
        self.flash.fill((WHITE))
        self.flash.set_alpha(self.flash_alpha)
        
        
        if self.level == 'home':
            self.map = self.map_home
            self.music = theme3
            self.music.stop()
            self.music.play(-1)     
            self.peacefull = False
            self.isfog = False
        if self.level == 'starter zone':
            self.map = self.map_starter_zone
            self.music = theme1
            self.music.stop()
            self.music.play(-1)
            self.peacefull = False
            self.isfog = False
        if self.level == 'starter cave':
            self.map = self.map_starter_cave
            self.music = theme4
            self.music.stop()
            self.music.play(-1)          
            self.peacefull = False
            self.isfog = False
        if self.level == 'boss room':
            self.map = self.map_boss_room
            self.music = theme2
            self.music.stop()
            self.music.play(-1)     
            self.peacefull = False
            self.isfog = False            
        if self.level == 'way out':
            self.map = self.map_way_out
            self.music = theme4
            self.music.stop()
            self.music.play(-1)     
            self.peacefull = False
            self.isfog = False
        if self.level == 'balconi':
            self.map = self.map_balconi
            self.music = theme6
            self.music.stop()
            self.music.play(-1)     
            self.peacefull = False
            self.isfog = False          
            self.bg = self.map_background1
            self.is_background = True
        else:
            self.is_background = False
            
        self.music.set_volume(self.music_volume)
        
        if self.is_background == True:
            self.bg_img = self.bg.make_map() 
            self.bg_rect = self.bg_img.get_rect()              
            #self.bg_img.convert_alpha()            
            self.bg_camera = Camera(self.bg.width, self.bg.height, 0.2)
          
        #creer l'image / rectangle de la carte.
        self.map_img = self.map.make_map() 
        self.map_rect = self.map_img.get_rect()        
        self.map_img.set_colorkey(COLORKEY)        
        self.map_img.convert_alpha()            

        #fait apparaitre la camera avec la bonne taille (celle de la carte)
        self.camera = Camera(self.map.width, self.map.height, 1)
        
        
        #tous les groupes de sprites, ne sont pas tous utiles mais permettent de mieux s'organiser et gerer les collisions entre groupes.
        
        self.all_sprites = pygame.sprite.LayeredDirty() #toutes les sprites qu'on voit a l'ecran 
        self.walls = pygame.sprite.Group()
        self.ladder = pygame.sprite.Group() #echelle
        self.warp1 = pygame.sprite.Group() #Les warps, ceux qui nous teleportent (pas ceux qui chargent une autre carte)
        self.warp2 = pygame.sprite.Group() #
        self.warp3 = pygame.sprite.Group() #
        self.warp4 = pygame.sprite.Group() #
        self.velos = pygame.sprite.LayeredDirty() #le velo
        self.players  = pygame.sprite.LayeredDirty() #les joueurs (je compte mettre un mode coop
        self.bullets = pygame.sprite.LayeredDirty() #les projectiles allies
        self.mob_bullets = pygame.sprite.LayeredDirty() #les projectiles enemis 
        self.mobs = pygame.sprite.LayeredDirty() #les monstres 
        self.warps = pygame.sprite.LayeredDirty() #les warp qui changent la carte.
        self.hud = pygame.sprite.LayeredDirty() #l'interface du jeu
        self.interface = pygame.sprite.LayeredDirty() #les elements du menu
        #lit les objets poses sur Tiled, et place les sprites a l'endroit ou j'ai pose l'objet.
        for tile_object in self.map.tmxdata.objects:

            if tile_object.name == 'portal': #si le nom de l'objet est:
                portalsprite = Portalsprite(self, tile_object.x, tile_object.y)  
                
            if tile_object.name == 'dummy':
                Dummy(self, tile_object.x, tile_object.y)    

            if tile_object.name == 'water': #si le type de l'objet est: 
                Water(self, tile_object.x, tile_object.y)
                
            if tile_object.type == 'bush':
                self.bush = Bush(self, tile_object.x, tile_object.y)
                self.all_sprites.move_to_back(self.bush)
                
            if tile_object.name == 'flower':
                Flower(self, tile_object.x, tile_object.y)
                
            if tile_object.name == 'darkrai':
                self.darkrai = Darkrai(self, tile_object.x, tile_object.y)
                
            if tile_object.name == 'falltop':
                Falltop(self, tile_object.x, tile_object.y)  
                
            if tile_object.name == 'fall':
                Waterfall(self, tile_object.x, tile_object.y) 
                
            if tile_object.name == 'bike':
                Velo(self, tile_object.x, tile_object.y)
        
            if tile_object.type == 'wall':
                Wall(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height) 
                
# AREAS # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

            if tile_object.name == 'starter zone':
                Warp(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, 'starter zone')
                
            if tile_object.name == 'home':
                Warp(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, 'home') 
                
            if tile_object.name == 'starter cave':
                Warp(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, 'starter cave')  
                
            if tile_object.name == 'boss room':
                Warp(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, 'boss room') 
                
            if tile_object.name == 'way out':
                Warp(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, 'way out')   
                    
            if tile_object.name == 'balconi':
                Warp(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, 'balconi')   
                
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #  

            if tile_object.name == 'ladder':
                Ladder(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height)  
                
            if tile_object.name == 'mystherbe':
                Mystherbe(self, tile_object.x, tile_object.y)  
                
            if tile_object.name == 'bed cover':
                object_image(self, tile_object.x, tile_object.y, bed_cover)
                                                
            if self.player_location == 1:
                if tile_object.name == 'player location 1':
                    self.player_location_x = tile_object.x
                    self.player_location_y = tile_object.y
                    
            if self.player_location == 2:
                if tile_object.name == 'player location 2':   
                    self.player_location_x = tile_object.x
                    self.player_location_y = tile_object.y 
                    
        self.player = Player(self, self.player_location_x, self.player_location_y) 
        self.all_sprites.move_to_front(self.player)                
        self.target = Camera_controls(self, "follow player")

        
        
        
    def boucle(self):
        self.fade_alpha = 300        
        self.playing = True
        self.loading = False
        while self.playing:
            actual_fps = clock.get_fps()     
            pygame.display.set_caption(str(actual_fps))                     
            self.dt = clock.tick(FPS) /1000
            self.timer = time.time()            
            self.events()
            self.update()
            self.draw()
            
            self.fade_alpha -= 4            
            fade_in.set_alpha(self.fade_alpha)
            screen.blit(fade_in,(0,0))       
            if self.fade_alpha <= 0:
                self.fade_alpha = 0
            
    def quit(self):
        #appeller cette fonction quitte le jeu.
        pygame.quit()
        sys.exit()
        
    def draw(self):
        screen.fill(0)
        
        if self.is_background:
            screen.blit(self.bg_img, self.bg_camera.applyrect(self.bg_rect))   
        
        screen.blit(self.map_img, self.camera.applyrect(self.map_rect))    
        for sprite in self.all_sprites:
            if  sprite.rect.colliderect(self.target.screen_rect):
                screen.blit(sprite.image, self.camera.apply(sprite))      
        
        
        self.Fog()
        self.interface.draw(screen)
        
        xpbar_bg = pygame.Surface((104, 4))
        xpbar_bg.fill(DARKGREY)
        
        healthbar_bg = pygame.Surface((100, 20))
        healthbar_bg.fill(DARKGREY)
        
        manabar_bg = pygame.Surface((100, 20))
        manabar_bg.fill(DARKGREY)
   
        if self.menu_open == False and not self.loading:
            screen.blit(xpbar_bg,( 40, HEIGHT - 50 + 32))
            screen.blit(manabar_bg,( 48, HEIGHT - 82))
            screen.blit(healthbar_bg,( 48, HEIGHT - 42))                 
            self.hud.draw(screen)
        
    def Fog(self):
        if self.isfog == True:
            self.fog.fill(self.fog_color)  
            #self.fog.set_alpha(200)
    def freeze_player(self):
        if self.menu_open == True:
            self.player_freeze = True
        else:
            self.player_freeze = False
            
    def boss_defeat(self):
        self.time_multiplier = self.time_multiplier_100 / 100
        if self.boss_defeated == True:
            self.doflash()
            self.time_wait += 1
            self.time_multiplier_100 = 20
            if self.time_wait >= 50:
                self.boss_defeated = False
        else:
            self.time_wait = 0 
            self.time_multiplier_100 += 1
            
            if self.time_multiplier_100 + 1 >= 100:
                self.time_multiplier_100 = 100
                
    def doflash(self):
        self.flash_alpha -= 4            
        self.flash.set_alpha(self.flash_alpha)
        screen.blit(self.flash,(0,0))  

    def update(self):
        self.boss_defeat()
        for sprite in self.all_sprites:
            #if  sprite.rect.colliderect(self.target.screen_rect):
            sprite.update()
                
        self.hud.update()
        self.interface.update()
        pygame.display.flip()
        if self.is_background:
            self.bg_camera.update(self.target)
        self.camera.update(self.target)        
        self.freeze_player()
    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_TAB:
                    self.quit() 
                if event.key == pygame.K_F11:
                    screen = pygame.display.set_mode((WIDTH, HEIGHT),FULLSCREEN)
                if event.key == pygame.K_F10:
                    screen = pygame.display.set_mode((WIDTH, HEIGHT))
                if event.key == pygame.K_ESCAPE:
                    if self.menu_open == False:
                        self.menu = Menu(self, WIDTH - 8 - 4 * TILESIZE, 8)
                        self.menu_open = True
                        open_menu_fx.play()
                    if self.menu_count >= 10:
                        if self.menu_open:
                            self.menu.kill()
                            self.menu_open = False
                            
                if event.key == pygame.K_a:   
                    if not self.player.collide_up and not self.player.collide_down:                    
                        self.player.walk_dir = 'left'
                    self.player.isleft_held = True
                if event.key == pygame.K_d:   
                    if not self.player.collide_up and not self.player.collide_down:                    
                        self.player.walk_dir = 'right'
                    self.player.isright_held = True
                if event.key == pygame.K_w:   
                    if not self.player.collide_right and not self.player.collide_left:                    
                        self.player.walk_dir = 'up'
                    self.player.isup_held = True
                if event.key == pygame.K_s:   
                    if not self.player.collide_right and not self.player.collide_left:                    
                        self.player.walk_dir = 'down'
                    self.player.isdown_held = True                    
                    
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:   
                    self.player.isleft_held = False
                    if self.player.isright_held:
                        self.player.walk_dir = 'right'
                    if self.player.isup_held:
                        self.player.walk_dir = 'up'
                    if self.player.isdown_held:
                        self.player.walk_dir = 'down'    
                        
                if event.key == pygame.K_d:   
                    self.player.isright_held = False     
                    if self.player.isleft_held:
                        self.player.walk_dir = 'left'
                    if self.player.isup_held:
                        self.player.walk_dir = 'up'
                    if self.player.isdown_held:
                        self.player.walk_dir = 'down'    
                        
                if event.key == pygame.K_w:   
                    self.player.isup_held = False
                    if self.player.isright_held:
                        self.player.walk_dir = 'right'
                    if self.player.isleft_held:
                        self.player.walk_dir = 'left'
                    if self.player.isdown_held:
                        self.player.walk_dir = 'down'    
                        
                if event.key == pygame.K_s:   
                    self.player.isdown_held = False       
                    if self.player.isright_held:
                        self.player.walk_dir = 'right'
                    if self.player.isup_held:
                        self.player.walk_dir = 'up'
                    if self.player.isleft_held:
                        self.player.walk_dir = 'left'                        
                    
        if self.menu_open == False:
            self.menu_count = 0
        else:
            self.menu_count += 1
        if self.menu_count >= 10:
            self.menu_count = 10            
    def exitscreen(self):
        #se joue apres la boucle.
        screen.fill(0) #evite un clignotement lors d'un changement de niveau 
        pygame.display.flip()
        #self.replay()
        
    def replay(self):
        #non utilise, permet au jeu d'attendre que l'on appuie sur une touche avant de se relancer 
        waiting = True
        while waiting:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.KEYUP:            
                    waiting = False
                    
# Le jeu etant une classe, on doit l'appeller ici.
g = Game()
while True:
    g.new_game()
    g.boucle()
    g.exitscreen()