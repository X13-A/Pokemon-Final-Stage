import pygame
from settings import *
vec = pygame.math.Vector2
import time 

def move(sprite, speed):
    if sprite.tiles_to_move > 0:
        if sprite.dir == 'left':
            sprite.velx = -speed 
        if sprite.dir == 'right':
            sprite.velx = speed 
        if sprite.dir == 'up':
            sprite.vely = -speed 
        if sprite.dir == 'down':
            sprite.vely = speed 
        sprite.tiles_to_move_count += speed
    if sprite.tiles_to_move_count > TILESIZE:
        sprite.tiles_to_move -= 1
        sprite.tiles_to_move_count = 0
    
        
        
def hide(sprite, offset):
    collide = pygame.sprite.spritecollide(sprite, sprite.game.players, False)
    if collide:
        if collide[0].rect.bottom > sprite.rect.centery + offset:
            sprite.game.all_sprites.move_to_back(sprite)
        else:
            sprite.game.all_sprites.move_to_front(sprite)
 
def light_shader(sprite, radius):

    if sprite.game.isfog == True:
        sprite.light_rect.center = sprite.game.camera.apply(sprite).center 
        sprite.game.fog.blit(sprite.light, sprite.light_rect)
        screen.blit(sprite.game.fog, (0, 0), special_flags = pygame.BLEND_MULT)           
        
def knockback_def (sprite):
    if sprite.knockback_dir == 'none':   
        sprite.intelligence()
        
    if sprite.knockback_dir == 'right':
        if sprite.knockback > 0:
            sprite.velx += sprite.knockback
            sprite.knockback -= 0.5
        else: 
            sprite.knockback_dir = 'none'
            
    if sprite.knockback_dir == 'left':
        if sprite.knockback > 0:
            sprite.velx -= sprite.knockback
            sprite.knockback -= 0.5
        else: 
            sprite.knockback_dir = 'none'  
            
    if sprite.knockback_dir == 'up':
        if sprite.knockback > 0:
            sprite.vely -= sprite.knockback
            sprite.knockback -= 0.5
        else: 
            sprite.knockback_dir = 'none'
            
    if sprite.knockback_dir == 'down':
        if sprite.knockback > 0:
            sprite.vely += sprite.knockback
            sprite.knockback -= 0.5
        else: 
            sprite.knockback_dir = 'none'                       

class TiledMap:
    def __init__(self,filename):
        tm = pytmx.load_pygame(filename, pixelalpha = True) #cette ligne charge la carte dans le jeu. pixelalpha permet d'avoir de la transparence sur la carte
        self.width = tm.width * tm.tilewidth #tm.width est le nombre de cases que la carte a en largeur, on multiplie par la taille de ces cases pour avoir la largeur totale.
        self.height = tm.height * tm.tileheight #pareil ici
        self.tmxdata = tm #permet d'acceder a tout cela en appelant tmxdata
        
    def render(self, surface):
        ti = self.tmxdata.get_tile_image_by_gid #trouve l'image de la case en fonction de son gid, le gid est un nombre attribue a chaque case ayant une image differente permettant de savoir quelle image dessiner.
        for layer in self.tmxdata.visible_layers: #visible layers represente tout les layers visibles sur tiled au moment ou vous sauvegardez
            if isinstance(layer, pytmx.TiledTileLayer): #si le layer est un layer de cases, et pas d'objets. (les objets sur tiled sont juste des rectangles avec un nom, on s'en servira pour faire apparaitres des sprites a l'endroit voulu)
                for x, y, gid, in layer: # donne les coordonnees et le gid de la case. (gid definit plus haut)
                    tile = ti(gid)
                    if tile: #si en lisant la carte, il voit une case (tile) et non un objet ou autres, dessine l'image de cette case a l'endroit ou elle est sur la carte 
                        surface.blit(tile, (x * self.tmxdata.tilewidth, y * self.tmxdata.tilewidth))
                        
    def make_map(self):
        #appeller cette fonction dessine la carte sur le jeu 
        temp_surface = pygame.Surface((self.width, self.height)) #creer une surface de la taille de la carte pour pouvoir dessiner la carte dessus.
        self.render(temp_surface) #dessine la carte.
        return temp_surface
    
    
   
    
class Camera:
    def __init__(self, width, height, scrollspeed):
        #on cr�e un objet cam�ra
        self.camera = pygame.Rect(0,0,width, height)
        self.width = width
        self.height = height
        self.scrollspeed = scrollspeed
        
    def apply(self, entity):
        #entity d�finit toutes les sprites sauf le joueur.
        #cette ligne d�placera toutes ces sprites en m�me temps que le rectangle self.camera 
        return entity.rect.move(self.camera.topleft)
    
    def applyrect(self, rect):
        #m�me chose qu'au dessus, cette commande d�placera l'image de la carte
        return rect.move(self.camera.topleft)
    
    def update(self, target):
        #target est la cible que la cam�ra suivra, ici ce sera le joueur.
        #x et y sont les coordon�es de la cam�ra, pas du joueur.
        #les coordon�es de la cam�ra d�pendent de celles du joueur:
        #si le joueur bouge � droite, la cam�ra doit bouger vers la gauche, d'ou le "-" devant target.rect 

        y = (-target.rect.y + HEIGHT / 2) * self.scrollspeed 
        x = (-target.rect.x + WIDTH / 2) * self.scrollspeed  
        
        x = min(0, x) #avec cette ligne, x aura pour maximum 0, de sorte � ce que la cam�ra s'arrete sur le bord gauche de la carte.
        y = min(0, y) #pareil ici, pour le bord haut de la carte.
        
        #ici, on ajoute le rectangle de la cam�ra � la commande, sans quoi les limites seraient incorectes. (c'est du au fait que les coordon�es du rectangle partent du coin haut gauche de celui ci. (ou elles sont � 0, 0)) 
        x = max(-(self.width - WIDTH), x) #avec cette ligne, x aura pour valeur maximale l'oppos� de (la largeur de la carte moins la largeur de la cam�ra), de sorte � ce que la cam�ra s'arrete sur le bord droit de la carte. 
        y = max(-(self.height - HEIGHT), y) #pareil ici, pour le bord bas de la carte. 
    
        self.camera = pygame.Rect(x, y, self.width, self.height) #cette ligne actualise la position de la cam�ra avec les coordon�es x et y definies avant.
        
        

        


def spawn_player_stats(sprite):
    #fonction simple permettant de faire apparaitre une seule fois les sprites des statistiques du joueur
    sprite.spawnstats += 1 #demarre un compteur 
    if sprite.spawnstats == 5: #si le compteur est a 5, fait apparaitre les stats.
        PlayerHealth(sprite.game, sprite)
        HealthBar(sprite.game,sprite)
        PlayerMana(sprite.game,sprite)
        ManaBar(sprite.game, sprite)
        PlayerXP(sprite.game, sprite)
        
    if sprite.spawnstats == 10:
        sprite.spawnstats = 10 #arrete le compteur


def spawn_mob_stats(sprite):
    #meme chose qu'au dessus, pour les monstres (mob)
    sprite.spawnstats += 1 
    if sprite.spawnstats == 5:   
        MobBar(sprite.game,sprite)
        MobHealth(sprite.game, sprite)

    if sprite.spawnstats == 10:
        sprite.spawnstats = 10




def collide_with_walls(sprite, group, direction, sprite_type):         
    #Collision avec les murs sur l'axe 'x'    
    if direction == 'x':
        for wall in sprite.game.walls:
            collide = sprite.hitbox.colliderect(wall.rect) #detecte les collisions entre la sprite voulue et le groupe de sprite voulu
            
            if collide and sprite.velx > 0:               
                sprite.x = wall.rect.left - sprite.hitbox.width #si la sprite va vers la droite, la droite du rectangle de la sprite se colle a la gauche du rectangle de l'obstacle
                if sprite_type == 'player':                   
                    sprite.collide_right = True   
            else:
                if sprite_type == 'player':                   
                    sprite.collide_right = False  
                    
            if collide and sprite.velx < 0: #meme chose pour la gauche 
                sprite.x = wall.rect.right
                if sprite_type == 'player':                   
                    sprite.collide_left = True   
            else:
                if sprite_type == 'player':                   
                    sprite.collide_left = False   
            


                        
            if collide:
                sprite.image = sprite.afk #pour que la sprite ait une image fixe quand elle se cogne.              
                sprite.velx = 0 #quand elle se cogne sur l'axe x, sa vitesse sur l'axe x se met a 0
                sprite.hitbox.x = sprite.x #sans cette ligne, la sprite s'arrete devant le mur mais quelques pixels dedans, cela causait des problemes. 
                sprite.rect.centerx = sprite.hitbox.centerx      
                
                if sprite_type == 'player':
                    if sprite.charging == True:
                        sprite.charging = False
                        sprite.game.target.shake_duration = 5  
                        crash_fx.play()
     
                        
        #Collision avec les murs sur l'axe 'y' , m�me chose qu'au dessus.
    if direction == 'y':    
        for wall in sprite.game.walls:
            collide = sprite.hitbox.colliderect(wall.rect)   
            
            if collide and sprite.vely > 0:
                sprite.y = wall.rect.top - sprite.hitbox.height
                if sprite_type == 'player':                   
                    sprite.collide_down = True   
            else:
                if sprite_type == 'player':                   
                    sprite.collide_down = False   
                    
            if collide and sprite.vely < 0:
                sprite.y = wall.rect.bottom
                if sprite_type == 'player':                   
                    sprite.collide_up = True   
            else:
                if sprite_type == 'player':                   
                    sprite.collide_up = False    
           
            if collide:
                sprite.image = sprite.afk
                sprite.vely = 0
                sprite.hitbox.y = sprite.y 
                
                if sprite_type == 'player':
                    sprite.rect.midbottom = sprite.hitbox.midbottom
                    if sprite.charging == True:
                        sprite.charging = False
                        sprite.game.target.shake_duration = 5
                        crash_fx.play()                      
                else: 
                    sprite.rect.centery = sprite.hitbox.centery
                    
 

                    
                    
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#LA PLUS PART DES SPRITES DE CE JEU UTILISENT LE MEME SYSTEME POUR SE POSITIONER / AVOIR UNE IMAGE DYNAMIQUE
#ON VA DONC EXPLIQUER CES SYTEMES QU'UNE SEULE FOIS.
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
class Stats(pygame.sprite.DirtySprite):
    def __init__(self, game):
        self.groups = game.interface
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.image = menu_stats
        self.rect = self.image.get_rect()
        self.rect.x = 8
        self.rect.y = 8 
        self.count = 0
        self.font = pygame.font.Font("resource1.tff", 24)
        self.smallfont = pygame.font.Font("resource1.tff", 12)
        
#LEVEL ----------------------------------------------------------------------------------------------------------------------        
        self.level = self.font.render('Level:' , False, (DARKGREY))  
        self.level_value = self.font.render(str(int(self.game.player.level)) , False, (DARKGREY))          
    
#HEALTH --------------------------------------------------------------------------------------------------------------------
        self.health = self.font.render('Health:' , False, (DARKGREY))           
        self.health_regen = self.smallfont.render(str(self.game.player.health_regen) , False, (DARKGREY))                         
        self.health_value = self.font.render(str(int(self.game.player.health)) , False, (DARKGREY))                 
        self.divide = self.font.render('/' , False, (DARKGREY))     
        self.plus = self.smallfont.render('+' , False, (DARKGREY))
        self.maxhealth = self.font.render(str(int(self.game.player.maxhealth)) , False, (DARKGREY))    
            
#MANA -----------------------------------------------------------------------------------------------------------
        self.mana = self.font.render('Mana:' , False, (DARKGREY))       
        self.mana_regen = self.smallfont.render(str(self.game.player.mana_regen) , False, (DARKGREY))                                 
        self.mana_value = self.font.render(str(int(self.game.player.mana)) , False, (DARKGREY))                 
        self.maxmana = self.font.render(str(int(self.game.player.maxmana)) , False, (DARKGREY))    
    
#STR ------------------------------------------------------------------------------------------------------------
        self.strength =  self.font.render('STRENGTH:' , False, (DARKGREY))       
        self.strength_value =  self.font.render(str(self.game.player.strength) , False, (DARKGREY))       
        
#XP -------------------------------------------------------------------------------------------------------------
        self.xp = self.font.render('XP:' , False, (LIGHTBLUE))  
        self.xp_value = self.font.render(str(int(self.game.player.xp)) , False, (LIGHTBLUE))  
        self.xp_max = self.font.render(str(int(self.game.player.next_level_xp)) , False, (LIGHTBLUE))
        self.xp_divide = self.font.render('/' , False, (LIGHTBLUE))     
#MONEY -----------------------------------------------------------------------------------------------------------
        self.copper_coins =  self.font.render(str(self.game.player_copper_coins) , False, (DARKGREY))       
        self.silver_coins =  self.font.render(str(self.game.player_silver_coins) , False, (DARKGREY))       
        self.gold_coins =  self.font.render(str(self.game.player_gold_coins) , False, (DARKGREY))    
        
        self.copper_coins_shadow =  self.font.render(str(self.game.player_copper_coins) , False, (LIGHTGREY))       
        self.silver_coins_shadow =  self.font.render(str(self.game.player_silver_coins) , False, (LIGHTGREY))       
        self.gold_coins_shadow =  self.font.render(str(self.game.player_gold_coins) , False, (LIGHTGREY))    
        
        self.copper = self.font.render('c', False, (COPPER))  
        self.copper_shadow = self.font.render('c', False, (LIGHTGREY))       
        
        self.silver = self.font.render('s', False, (SILVER))
        self.silver_shadow = self.font.render('s', False, (LIGHTGREY))
        
        self.gold = self.font.render('g', False, (GOLD))
        self.gold_shadow = self.font.render('g', False, (LIGHTGREY))        
        
    def quit(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
            self.game.menu.showing_stats = False 
            self.kill()
            
    def draw_stats(self):

        screen.blit(self.level, (self.rect.x + 448, self.rect.y + 20))
        screen.blit(self.level_value, (self.rect.x + 448 + self.level.get_width() + 32 , self.rect.y + 20))       
        
        screen.blit(self.health, (self.rect.x + 32, self.rect.y +96)) 
        screen.blit(self.maxhealth, (self.rect.x + self.rect.width - 352 - self.maxhealth.get_width(), self.rect.y + 96))
        screen.blit(self.plus, (self.rect.x + self.rect.width - 352, self.rect.y + 96))
        screen.blit(self.health_regen, (self.rect.x + self.rect.width - 352 + self.plus.get_width(), self.rect.y + 96))        
        screen.blit(self.divide, (self.rect.x + self.rect.width - 352 - self.maxhealth.get_width() - self.divide.get_width(), self.rect.y + 96))
        screen.blit(self.health_value, (self.rect.x + self.rect.width - 352 - self.maxhealth.get_width() - self.divide.get_width() - self.health_value.get_width(), self.rect.y + 96))  
        
        screen.blit(self.mana, (self.rect.x + 32, self.rect.y +96 + 48)) 
        screen.blit(self.maxmana, (self.rect.x + self.rect.width - 352 - self.maxmana.get_width(), self.rect.y + 96 + 48))
        screen.blit(self.plus, (self.rect.x + self.rect.width - 352, self.rect.y + 96 + 48))        
        screen.blit(self.mana_regen, (self.rect.x + self.rect.width - 352 + self.plus.get_width(), self.rect.y + 96 + 48))                
        screen.blit(self.divide, (self.rect.x + self.rect.width - 352 - self.maxmana.get_width() - self.divide.get_width(), self.rect.y + 96 + 48))
        screen.blit(self.mana_value, (self.rect.x + self.rect.width - 352 - self.maxmana.get_width() - self.divide.get_width() - self.mana_value.get_width(), self.rect.y + 96 + 48))        
               
        screen.blit(self.strength, (self.rect.x + 32, self.rect.y +96 + 48 * 2))
        screen.blit(self.strength_value, (self.rect.x + self.rect.width - 352 - self.strength_value.get_width(), self.rect.y + 96 + 48 * 2))

        screen.blit(self.xp, (self.rect.x + 32, self.rect.y + self.rect.height - 64)) 
        screen.blit(self.xp_max, (self.rect.x + self.rect.width -32 - self.xp_max.get_width() , self.rect.y + self.rect.height - 64))
        screen.blit(self.xp_divide, (self.rect.x + self.rect.width -32 - self.xp_max.get_width() - self.xp_divide.get_width() ,  self.rect.y + self.rect.height - 64))
        screen.blit(self.xp_value, (self.rect.x + self.rect.width -32 - self.xp_max.get_width() - self.xp_divide.get_width() - self.xp_value.get_width(),  self.rect.y + self.rect.height - 64))    
        
        screen.blit(self.gold_shadow, (self.rect.x + self.rect.width - 32 - self.gold.get_width() + 2, self.rect.y + 96 + 2))
        screen.blit(self.gold, (self.rect.x + self.rect.width - 32 - self.gold.get_width(), self.rect.y + 96))
        
        screen.blit(self.gold_coins_shadow, (self.rect.x + self.rect.width - 32 - self.gold.get_width() - self.gold_coins.get_width()+ 2, self.rect.y + 96 + 2))        
        screen.blit(self.gold_coins, (self.rect.x + self.rect.width - 32 - self.gold.get_width() - self.gold_coins.get_width(), self.rect.y + 96))
        
        screen.blit(self.silver_shadow, (self.rect.x + self.rect.width - 32 - self.silver.get_width() - 64 + 2 , self.rect.y + 96 + 2))        
        screen.blit(self.silver, (self.rect.x + self.rect.width - 32 - self.silver.get_width() - 64 , self.rect.y + 96 ))
        
        screen.blit(self.silver_coins_shadow, (self.rect.x + self.rect.width - 32 - self.silver.get_width() - 64 - self.silver_coins.get_width() + 2, self.rect.y + 96 + 2))                
        screen.blit(self.silver_coins, (self.rect.x + self.rect.width - 32 - self.silver.get_width() - 64 - self.silver_coins.get_width(), self.rect.y + 96))        

        screen.blit(self.copper_shadow, (self.rect.x + self.rect.width - 32 - self.copper.get_width() - 128 + 2, self.rect.y + 96 + 2))           
        screen.blit(self.copper, (self.rect.x + self.rect.width - 32 - self.copper.get_width() - 128, self.rect.y + 96))
        
        screen.blit(self.copper_coins_shadow, (self.rect.x + self.rect.width - 32 - self.copper.get_width() - 128 - self.copper_coins.get_width() + 2, self.rect.y + 96 + 2))         
        screen.blit(self.copper_coins, (self.rect.x + self.rect.width - 32 - self.copper.get_width() - 128 - self.copper_coins.get_width(), self.rect.y + 96)) 
  
        
    def update(self):
        self.draw_stats()
        self.quit()
        self.dirty = 1
        

class Menu(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        self.groups = game.interface
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.image = menu1
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y 
        self.selection = 0
        self.timer = 0
        self.timer_up = 9
        self.timer_down = 9
        self.showing_stats = False 
        self.font = pygame.font.Font("pkmndp.tff", 48)
        self.resume = self.font.render('RESUME' , False, (74,74,74))                 
        self.resume_shadow = self.font.render('RESUME' , False, (LIGHTGREY))  
        self.quit = self.font.render('QUIT' , False, (74,74,74))                 
        self.quit_shadow = self.font.render('QUIT' , False, (LIGHTGREY))
        self.stats = self.font.render('STATS' , False, (74,74,74))                 
        self.stats_shadow = self.font.render('STATS' , False, (LIGHTGREY)) 
        self.map = self.font.render('MAP' , False, (74,74,74))                 
        self.map_shadow = self.font.render('MAP' , False, (LIGHTGREY))
        self.mute_shadow = self.font.render('MUTE' , False, (LIGHTGREY))        
        if self.game.music_muted == False:
            self.mute = self.font.render('MUTE' , False, (74,74,74))  
        else:
            self.mute = self.font.render('MUTE' , False, (255,150,0)) 
            
    def Resume(self):      
        screen.blit(self.resume_shadow, (self.rect.x + 96 + 1, self.rect.y +32 + 2))       
        screen.blit(self.resume, (self.rect.x + 96, self.rect.y +32))        
        keys = pygame.key.get_pressed()        
        if self.selection == 0 and keys[pygame.K_RETURN]:
            self.kill()
            self.game.menu_open = False  
            if self.showing_stats == True:
                self.stats_menu.kill()
                self.showing_stats = False
                
    def Quit(self):          
        screen.blit(self.quit_shadow, (self.rect.x + 96 + 1, self.rect.y +32 + 2 + 64))       
        screen.blit(self.quit, (self.rect.x + 96, self.rect.y +32 + 64))  
        keys = pygame.key.get_pressed()        
        if self.selection == 1 and keys[pygame.K_RETURN]:
                self.game.quit()
                
    def Stats(self):          
        screen.blit(self.stats_shadow, (self.rect.x + 96 + 1, self.rect.y +32 + 2 + 64 * 2))       
        screen.blit(self.stats, (self.rect.x + 96, self.rect.y +32 + 64 * 2))        
        keys = pygame.key.get_pressed()        
        if self.selection == 2 and keys[pygame.K_RETURN]:
            if self.showing_stats == False:
                self.stats_menu = Stats(self.game)
                self.showing_stats = True 
                select_fx.play()
                
    def Map(self):
        screen.blit(self.map_shadow, (self.rect.x + 96 + 1, self.rect.y +32 + 2 + 64 * 3))       
        screen.blit(self.map, (self.rect.x + 96, self.rect.y +32 + 64 * 3))
        keys = pygame.key.get_pressed()                
        if self.selection == 3 and keys[pygame.K_RETURN]:
            if self.showing_stats == True:
                self.stats_menu.kill()
            Boug(self.game, self.game.target.rect.x, self.game.target.rect.y)
            self.kill()
            self.game.target.function = "map"
                
    def Mute(self):
        screen.blit(self.mute_shadow, (self.rect.x + 96 + 1, self.rect.y +32 + 2 + 64 * 4))       
        screen.blit(self.mute, (self.rect.x + 96, self.rect.y +32 + 64 * 4))   
        keys = pygame.key.get_pressed()   
        
        if self.selection == 4 and keys[pygame.K_RETURN]:
            self.timer += 1
            if self.timer == 1:
                select_fx.play()
                if self.game.music_muted  == False:
                    self.game.music_volume = 0 
                    self.game.music.set_volume(self.game.music_volume)
                    self.mute = self.font.render('MUTE' , False, (255,150,0))                                     
                    self.game.music_muted = True
                elif self.game.music_muted == True:
                    self.game.music_volume = 0.5 
                    self.game.music.set_volume(self.game.music_volume)
                    self.mute = self.font.render('MUTE' , False, (74,74,74))                                     
                    self.game.music_muted = False
        else:
            self.timer = 0
    def Select(self):
        keys = pygame.key.get_pressed()
        self.arrow = screen.blit(arrow1, (self.rect.x + 32 , self.rect.y +32 + self.selection * 64))              
        if self.selection < 4:
            if keys [pygame.K_DOWN]:
                self.timer_down += 1
                if self.timer_down >= 10:
                    select_fx.play()                
                    self.selection += 1
                    self.timer_down = 0
            else:
                self.timer_down = 9
        if self.selection > 0:
            if keys [pygame.K_UP]:
                self.timer_up += 1
                if self.timer_up >= 10:
                    select_fx.play()                
                    self.selection -= 1
                    self.timer_up = 0
            else:
                self.timer_up = 9    
        

    
    def update(self):
        self.Select()
        self.Resume()
        self.Quit()
        self.Stats()
        self.Map()
        self.Mute()
        self.dirty = 1 

class Camera_controls(pygame.sprite.DirtySprite):
    def __init__(self, game, function):
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.function = function 
        self.image = vide 
        self.rect = self.image.get_rect()    
        self.pos = vec(self.rect.center)                
        self.shake_duration = 0
        self.vel = vec(self.game.player.rect.center)  
        self.velx = 0
        self.vely = 0
        self.offset_y = 0
        self.offset_x = 0        
        self.offset_vel = 5
        self.offset_vely = self.offset_vel
        self.max_offset = 5
        self.count = 0
        self.rect.x = self.game.player.rect.x + self.offset_x
        self.rect.y = self.game.player.rect.y + self.offset_y
        self.screen_rect = pygame.rect.Rect(self.rect.x - WIDTH/2, self.rect.y - HEIGHT/2, WIDTH, HEIGHT)        
        self.movespeed = 6
        #new camera
        #self.vel = (0,0)
        #self.acc = (0,0)
      
    def ScreenRect(self):
        
        y = self.rect.y - HEIGHT/2
        x = self.rect.x - WIDTH/2
        
        if x <= 0:
            x = 0
        if x + self.screen_rect.width >= self.game.map.width:
            x = self.game.map.width - self.screen_rect.width
        if y <= 0:
            y = 0
        if y + self.screen_rect.height >= self.game.map.height:
            y = self.game.map.height - self.screen_rect.height 
            
        self.screen_rect.topleft = (x,y)

    def smooth_camera(self):
        
        self.player_distance_x = (abs((self.rect.centerx - self.game.player.rect.centerx)))
        self.player_distance_y = (abs((self.rect.centery - self.game.player.rect.centery)))        
        self.player_distance = self.player_distance_x + self.player_distance_y
        
        self.rect.center = self.pos
        self.rot = (self.game.player.pos - self.pos).angle_to(vec(1, 0))
        self.acc = vec(self.player_distance/20, 0).rotate(-self.rot)
        if self.player_distance > 1:        
            self.vel += self.acc 
        self.pos = self.vel 
        self.rect.center = self.pos + (self.offset_x, self.offset_y)
        self.image = vide
        

    def shake(self):
        if self.shake_duration > 0 or self.offset_y != 0:
            self.offset_y += self.offset_vely

            if self.offset_y >= self.max_offset:
                self.offset_vely = -self.offset_vel
                self.shake_duration -= 1
            if self.offset_y <= -self.max_offset:
                self.offset_vely = self.offset_vel   
                
    def movemap(self):
        keys = pygame.key.get_pressed()

        self.image = crosshair
        
        self.rect.x += self.velx
        self.rect.y += self.vely
        
        if keys[pygame.K_LSHIFT]:
            self.movespeed = 12
        else:
            self.movespeed = 6
            
        if keys[pygame.K_a]:
            self.velx = -self.movespeed
        if keys[pygame.K_d]:
            self.velx = self.movespeed
        if not keys[pygame.K_a] and not keys[pygame.K_d]:
            self.velx = 0    
            
        if keys[pygame.K_w]:
            self.vely = -self.movespeed
        if keys[pygame.K_s]:
            self.vely = self.movespeed
        if not keys[pygame.K_w] and not keys[pygame.K_s]:
            self.vely = 0   
            

            
        if keys[pygame.K_ESCAPE]:
            self.function = "follow player"
            self.game.menu_open = False                  
        
        if keys[pygame.K_RETURN]:
            self.game.player.rect.topleft = self.rect.topleft
            self.game.player.x = self.rect.x
            self.game.player.y = self.rect.y
    def update(self):
        self.shake()
        self.ScreenRect()
        if self.function == "map":
            self.movemap()
            
        if self.function == "follow player": 
            self.smooth_camera()

class Damage_img(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y, damage, sprite, size, shadow, speed, crit):
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.damage = damage
        self.sprite = sprite  
        self.speed = speed
        self.iscrit = crit
        self.width = 0
        self.image = vide 
        self.rect = self.image.get_rect()  
        self.rect.topleft = (x, y)
        self.alpha = 400
        self.x = x
        self.y = y        
        
        self.value = str(round(-self.damage))
        self.surface= pygame.Surface((200, 200))
        self.surface.fill(COLORKEY)   
        self.surface.set_colorkey(COLORKEY)
        
        if self.iscrit == 2:
            self.font = pygame.font.Font("resource1.tff", size * 4)
            self.text = self.font.render(self.value , False, (RED))                 
            self.text_shadow = self.font.render(self.value , False, (BLACK))                        
            self.surface.blit(self.text_shadow, (shadow * 4, shadow * 4))        
            self.surface.blit(self.text, (0, 0))      
            super_critical_hit_fx.play()
            self.game.flashing = True
            self.game.target.shake_duration = 10
            
        if self.iscrit == 1:
            self.font = pygame.font.Font("resource1.tff", size * 2)
            self.text = self.font.render(self.value , False, (ORANGE))                 
            self.text_shadow = self.font.render(self.value , False, (BLACK))                        
            self.surface.blit(self.text_shadow, (shadow * 2, shadow * 2))        
            self.surface.blit(self.text, (0, 0))      
            critical_hit_fx.play()
            self.game.target.shake_duration = 5
            
        if self.iscrit == 0:
            self.font = pygame.font.Font("resource1.tff", size)
            self.text = self.font.render(self.value , False, (WHITE))     
            self.text_shadow = self.font.render(self.value , False, (BLACK))                        
            self.surface.blit(self.text_shadow, (shadow, shadow))        
            self.surface.blit(self.text, (0, 0))
            
        self.width = self.text.get_width()
        


        
        import random 
        self.random = random.randint(0,16)
        
    def animation(self):
        self.y -= self.speed * self.game.time_multiplier
        self.alpha -= 5 * self.speed  * self.game.time_multiplier
        if self.alpha - 5 <= 0:
            self.kill()
        self.surface.set_alpha(self.alpha)
        self.image = self.surface

        
    def update(self):
        self.animation()
        self.rect.x = self.sprite.rect.centerx + self.random - 8 - self.width / 2
        self.rect.y = self.y
        self.dirty = 1
class Dummy(pygame.sprite.DirtySprite):

    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.mobs
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game   
        self.image = walkDown[1]
        self.rect = self.image.get_rect() 
        self.rect.topleft = (x, y)        
        self.hitbox = self.rect
        self.losthealth = 0
        
    def update(self):
        self.dirty = 1  
        
class Portalsprite(pygame.sprite.DirtySprite):
    #sprite cosmetique
    #on utilise des dirty sprites pour des raisons d'optimisation.
    def __init__(self, game, x, y):
        self.groups = game.all_sprites #met la sprite dans le groupe voulu 
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.frameCount = 0 #sera utilise pour un compteur 
        self.frameSpeed = 20 #sera utilise pour regler l'affichage d'images. frameMax sur framespeed doit etre egal au nombre d'images de la liste.
        self.frameMax = 60 #le maximum que le compteur frameCount peut atteindre
        self.image = portalafk #image initiale de la sprite 
        self.rect = self.image.get_rect() #obtient un rectangle a partir de l'image
        self.rect.topleft = (x, y)        
   
    def update(self):
        self.frameCount += 2 * self.game.time_multiplier #fait monter le compteur a chaque instant
        if self.frameCount >= self.frameMax: #si le compteur atteint son maximum, il revient a 0
            self.frameCount = 0              #De sorte a ce que l'animation de l'image se repete en boucle 
        self.image = (portal_image[int(self.frameCount)//self.frameSpeed]) #utilise la liste d'images de la sprite, 
        #l'image affichee depend de la valeur du compteur, on divise frameCount par frameSpeed car il y a 3 images dans la liste d'images, le compteur pouvant atteindre 60, on le divise par 20 pour qu'il atteigne 3. 
        self.dirty = 1

class Velo(pygame.sprite.DirtySprite):
    #la sprite du velo 
    #quand le joueur le touchera, il montera dessus (cette fonction est dans le classe Player)
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.velos
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game   
        self.image = velo
        self.rect = self.image.get_rect() 
        self.rect.topleft = (x, y)        
    def update(self):
        self.dirty = 1  

class Water(pygame.sprite.DirtySprite):
    #Sprite non utilisee et purement cosmetique, c'est un carre d'eau anime.
    def __init__(self, game, x, y):
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.frameCount = 0
        self.frameSpeed = 18
        self.frameMax = 120     
        self.image = waterafk
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y) 
        
    def update(self):
        self.frameCount += 1 * self.game.time_multiplier
        
        if self.frameCount == self.frameMax:
            self.frameCount = 0
        self.image = (waterTile[int(self.frameCount)//self.frameSpeed])
        self.dirty = 1
        
class Player(pygame.sprite.DirtySprite):  
    #Le joueur, la sprite la plus complexe.
    def __init__(self, game, x, y):
        self.groups = game.players, game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.image = self.game.player_direction
        self.rect = self.image.get_rect() 
        self.rect.topleft = (x, y) 
        self.x = x
        self.y = y
        self.hitbox = pygame.Rect (0, 0, 64, 64) #hitbox du joueur, j'ai l'intention de l'exploiter pour faire des collisions plus precises.
#animation------------------------------------------------------------------------------------------
        self.frameCount = 5
        self.framespeed = 5
        self.framemax = 15   
        self.stepUp = walkUp #comme le joueur a plusieures animations differentes en fonction de si il court, marche, est en velo, etc, on utilise self.stepup pour determiner quelle liste d'images afficher.
        self.stepDown = walkDown #si il court, on change self.stepUp = walkDown en self.stepUp = runDown par exemple.
        self.stepLeft = walkLeft
        self.stepRight = walkRight        
        self.afk = self.game.player_direction #image quand le personnage ne bouge pas, elle changera en fonction de la direction. 
        self.charging = False
        self.tiles_to_move = 0
        self.tiles_to_move_count = 0
        self.tile_move_count = 0 
        if self.afk == walkDown[1]:
            self.dir = 'down'
        if self.afk == walkUp[1]:
            self.dir = 'up'
        if self.afk == walkLeft[1]:
            self.dir = 'left'
        if self.afk == walkRight[1]:
            self.dir = 'right'
#divers-----------------------------------------------------------------------------------------------
        self.hitCount = 0
        self.velo = 0 #valeur qu'on ajoute a la vitesse du joueur, elle passe a 4 si on est sur le velo
        self.spawnstats = 0 
        self.spawnshield = 0        
        
        if self.game.player_vehicle == 'bike':
            self.rider = True
        else:
            self.rider = False
            
        self.running = False
        self.alive = True
        self.run = 0
        self.hit = 0
        self.velx = 0
        self.vely = 0
        self.playerspeed = 4
        self.collide_left = False
        self.collide_right = False
        self.collide_up = False
        self.collide_down = False     
        self.walk_dir = 'none'   
        self.isleft_held = False
        self.isright_held = False
        self.isup_held = False
        self.isdown_held = False

        #shield----------------------------------------------------------------------------------------------
        self.shield = Shield(self.game, self)
        self.shielded = False
        self.shield_manacost = 0.5
#stats-------------------------------------------------------------------------------------------------
        self.strength = self.game.player_strength
        self.losthealth = 0 #la vie que le joueur a perdu
        self.maxhealth = 200 #vie maximum du joueur         
        self.health = self.maxhealth - self.losthealth #la vie actelle du joueur (la vie maximum moins la vie perdue).
        
        self.lostmana = 0 #pareil que pour la la vie 
        self.maxmana = 100 #pareil que pour la la vie  
        self.mana = self.maxmana - self.lostmana #pareil que pour la la vie 
#shaders ---------------------------------------------------------------------------------------------
        self.light = light_circle
        self.light = pygame.transform.scale(self.light, (self.light.get_width() * 1 , self.light.get_height() * 1))
        self.light_rect = self.light.get_rect()   
        self.blur_count = 0        
        
#shoot------------------------------------------------------------------------------------------------
        self.fire_count = bulletrate #compteur permettant de savoir si le joueur peut tirer ou pas. 
        self.shoot_manacost = 5
        self.bullet_damage = 2 * self.strength 
        self.knockback = 2
        self.shooting = False
        self.charge_damage = 5 * self.strength 
        self.charge_cooldown = 0
        self.charge_manacost = 50
        self.charge_speed = 128
#argent -----------------------------------------------------------------------------------------------
    
    def charge(self):           
            if self.game.timer >= self.charge_cooldown and self.mana >= self.charge_manacost:
                keys = pygame.key.get_pressed()
                if keys[pygame.K_1] and self.charging == False:
                    self.charge_posx = self.rect.x
                    self.charge_posy = self.rect.y
                    self.charging = True
                    dash_fx.play()
                    self.lostmana += self.charge_manacost
                    self.charge_cooldown = self.game.timer + 5      
            else:
                print ("cooldown", self.charge_cooldown - self.game.timer)
                
            if self.charging == True:
                if self.dir == 'up':
                    self.vely = -self.charge_speed
                    self.image = runUp[1]
                if self.dir == 'down':
                    self.vely = self.charge_speed
                    self.image = runDown[1]                
                if self.dir == 'left':
                    self.velx = -self.charge_speed
                    self.image = runLeft[1]                
                if self.dir == 'right':
                    self.velx = self.charge_speed             
                    self.image = runRight[1]                
                for sprite in self.game.mobs:
                    collidemob = self.hitbox.colliderect(sprite.hitbox)
                    if collidemob:
                        sprite.losthealth += self.charge_damage
                        Damage_img(self.game, sprite.rect.centerx, sprite.rect.y - 64, self.charge_damage, sprite, 16, 2, 1, 1)
                        crash_fx.play()                                              
                        self.charging = False 
                        self.game.target.shake_duration = 5
                        sprite.knockback = 5
                        sprite.knockback_dir = self.dir 
                self.charge_range = abs((self.charge_posx - self.rect.x ) + (self.charge_posy - self.rect.y))
                if self.charge_range >= 64 * 5:
                    self.charging = False 
                
    def money(self):
        
        self.copper_coins = self.game.player_copper_coins
        self.silver_coins = self.game.player_silver_coins
        self.gold_coins = self.game.player_gold_coins
        
        if self.game.player_copper_coins >= 100:
            self.game.player_copper_coins -= 100
            self.game.player_silver_coins += 1
            
        if self.game.player_silver_coins >= 100:
            self.game.player_silver_coins -= 100
            self.game.player_gold_coins += 1        
        
    def level_up (self):
        #les stats sont stock�es en dehors de la boucle de sorte � ce qu'elles ne se r�initialisent pas lorsque l'on meurt ou change de carte.
        self.level = self.game.player_level
        self.mana_regen = self.game.player_mana_regen 
        self.health_regen = self.game.player_health_regen      
        self.maxhealth = self.game.player_max_health
        self.maxmana = self.game.player_max_mana 
        self.strength = self.game.player_strength        
        self.bullet_damage = 2 * self.game.player_strength
        self.charge_damage = 10 * self.game.player_strength         
        self.xp = self.game.player_xp
        self.level_xp = 1.25 *((self.level - 1) **3) 
        self.next_level_xp = 1.25 *(self.level **3) 
        if self.xp >= self.next_level_xp:
            self.game.player_level += 1
            self.game.player_mana_regen += 0.1
            self.game.player_health_regen += 0.2
            self.game.player_max_health += 20 
            self.game.player_max_mana += 10
            self.game.player_strength += 1         
            levelup_sound.play()
            
    def cast_shield (self):
        #cette fonction permet l'utilisation du bouclier 
        keys = pygame.key.get_pressed() #permet d'utiliser une touche en continu 
        
        if keys[pygame.K_SPACE] and self.mana >= self.shield_manacost:  #si le joueur a assez de mana, active le bouclier.            
            self.spawnshield += 1 
            self.lostmana += self.shield_manacost #fais descendre la mana au fur et a mesure qu'on utilise le bouclier 
            self.shielded = True #permet au jeu de savoir si le joueur est protege.
            if self.spawnshield == 2:
                self.shield = Shield(self.game, self)
        else:
            self.shielded = False  
            self.shield.is_alive = False #tue la sprite bouclier (voir class Shield)
            self.spawnshield = 0
            
    def death(self):
        #tue la sprite du joueur si sa vie tombe a 0
        #On actualise les stats

        
        if self.health <= 0:
            self.alive = False
        if self.alive == False:
            self.kill()
            self.game.fadeout(1024, 576) #affiche un effet de fondu
            for sprite in self.game.all_sprites:
                sprite.kill()
            for sprite in self.game.hud:
                sprite.kill()
            for sprite in self.game.interface:
                sprite.kill()
            self.game.playing = False #relance la partie 
            
    def stats_regen(self):
        
        self.health = self.maxhealth - self.losthealth
        self.mana = self.maxmana - self.lostmana
        self.losthealth -= self.health_regen
        self.lostmana -= self.mana_regen
        
        if self.losthealth <= 0:
            self.losthealth = 0
        if self.lostmana <= 0:
            self.lostmana = 0

    def collide_ladder(self):    
    #Vitesse et animation change si le joueur grimpe l'echelle
        collide = pygame.sprite.spritecollide(self, self.game.ladder, False)  
        if collide:
            self.playerspeed = 2
            self.image = (walkUp[int(self.frameCount)//self.framespeed])

    def collidevelo(self):  
    #dit au jeu que le joueur est sur le velo, quand il l'attrape 
        keys = pygame.key.get_pressed()            
        collidevelo = pygame.sprite.spritecollide(self, self.game.velos, False)
        if collidevelo:
            if keys[pygame.K_e]:
                collidevelo[0].kill()
                dringvelo.play()
                self.rider = True
                self.game.player_vehicle = 'bike'
        if self.rider == True:  #si le joueur est sur le velo, il va plus vite (self.velo s'additione a la vitesse du joueur).
            self.velo = 4
            if keys[pygame.K_SPACE]:
                self.rider = False
                self.game.player_vehicle = 'none'                
        else: 
            self.velo = 0 #le joueur ralentit


 
    def controls(self):
        self.velx = 0 #on actuallise la vitesse a 0, de sorte a ce que le joueur ne continue pas d'avancer si on arreter d'appuyer sur les touches.
        self.vely = 0
        
        keys = pygame.key.get_pressed()    
        if keys[pygame.K_LSHIFT] and not self.shooting:  #dit au jeu qu'on est en train de courir 
            self.running = True
        else:
            self.running = False

        if self.running == True: #si l'on court, change l'animation du joueur 
            self.stepUp = runUp
            self.stepDown = runDown
            self.stepLeft = runLeft
            self.stepRight = runRight  
            self.run = 4 # s'ajoute a la vitesse du joueur, il va donc plus vite 
            
        else:
            self.run = 0 # il ne court plus et ralentit
            
        if self.rider == True: #change l'animation du joueur quand il est sur le velo
            self.stepUp = veloUp
            self.stepDown = veloDown
            self.stepLeft = veloLeft
            self.stepRight = veloRight  

        if self.rider == False and self.running == False: #le joueur se met a marcher si il n'est ni sur le velo, ni en train de courir 
            self.stepUp = walkUp
            self.stepDown = walkDown
            self.stepLeft = walkLeft
            self.stepRight = walkRight  

        if self.rider == True and keys[pygame.K_LSHIFT]: #accelere la vitesse a laquelle l'animation du joueur defile, pour simuler un pedalement plus rapide 
            self.framespeed = 3
            self.framemax = 9  

        else:
            self.framespeed = 5
            self.framemax = 15  






    def move (self):
        move(self, self.playerspeed)        
        keys = pygame.key.get_pressed()   
        
        self.frametime = 1 * self.game.time_multiplier
        if self.frameCount + self.frametime >= self.framemax: 
            self.frameCount = 0        
            
        if self.tiles_to_move >= 1:
            self.frameCount += self.frametime 
            if self.dir == 'left':
                self.image = (self.stepLeft[int(self.frameCount)//self.framespeed]) 
            if self.dir == 'right':
                self.image = (self.stepRight[int(self.frameCount)//self.framespeed]) 
            if self.dir == 'up':
                self.image = (self.stepUp[int(self.frameCount)//self.framespeed])     
            if self.dir == 'down':
                self.image = (self.stepDown[int(self.frameCount)//self.framespeed])       
                
        if self.tiles_to_move == 0:        
            if keys[pygame.K_q]:
                self.tile_move_count += 1
                self.dir = 'left'            
                if self.tile_move_count == 5:
                    self.tiles_to_move = 1
                    self.tiles_to_move_count += self.playerspeed
                if self.tiles_to_move_count >= TILESIZE:
                    self.tiles_to_move += 1
                if self.rider == True:
                    self.afk = veloL2 
                if self.rider == False:
                    self.afk = L2 
                    
            elif keys[pygame.K_d]:
                self.tile_move_count += 1
                self.dir = 'right'            
                if self.tile_move_count == 5:
                    self.tiles_to_move = 1
                    self.tiles_to_move_count += self.playerspeed
                if self.tiles_to_move_count >= TILESIZE:
                    self.tiles_to_move += 1
                if self.rider == True:
                    self.afk = veloL2 
                if self.rider == False:
                    self.afk = R2    
                    
            elif keys[pygame.K_z]:
                self.tile_move_count += 1
                self.dir = 'up'            
                if self.tile_move_count == 5:
                    self.tiles_to_move = 1
                    self.tiles_to_move_count += self.playerspeed
                if self.tiles_to_move_count >= TILESIZE:
                    self.tiles_to_move += 1
                if self.rider == True:
                    self.afk = veloL2 
                if self.rider == False:
                    self.afk = U2 
                    
            elif keys[pygame.K_s]:
                self.tile_move_count += 1
                self.dir = 'down'            
                if self.tile_move_count == 5:
                    self.tiles_to_move = 1
                    self.tiles_to_move_count += self.playerspeed
                if self.tiles_to_move_count >= TILESIZE:
                    self.tiles_to_move += 1
                if self.rider == True:
                    self.afk = veloL2 
                if self.rider == False:
                    self.afk = D2    
            else:
                self.tile_move_count = 0
                self.image = self.afk
                
    def walk(self, direction):
        if self.frameCount + self.frametime >= self.framemax: 
            self.frameCount = 0 
            
        if direction == 'left':
            self.frameCount += self.frametime 
            self.image = (self.stepLeft[int(self.frameCount)//self.framespeed]) 
            self.velx = -self.playerspeed
            if self.rider == True:
                self.afk = veloL2 
            if self.rider == False:
                self.afk = L2 
            self.dir = 'left'  
            
        if direction == 'right': 
            self.frameCount += self.frametime
            self.image = (self.stepRight[int(self.frameCount)//self.framespeed])
            self.velx = self.playerspeed            
            if self.rider == True:
                self.afk = veloR2 
            if self.rider == False:
                self.afk = R2            
            self.dir = 'right'
            
        if direction == 'up':
            self.frameCount += self.frametime
            self.image = (self.stepUp[int(self.frameCount)//self.framespeed])
            self.vely = -self.playerspeed
            if self.rider == True:
                self.afk = veloU2  
            if self.rider == False:
                self.afk = U2            
            self.dir = 'up'
    
        if direction == 'down': 
            self.frameCount += self.frametime
            self.image = (self.stepDown[int(self.frameCount)//self.framespeed])
            self.vely = self.playerspeed
            if self.rider == True:
                self.afk = veloD2 
            if self.rider == False:
                self.afk = D2            
            self.dir = 'down'        
            
    def freemove (self):
        keys = pygame.key.get_pressed()    
            
        if not keys[pygame.K_s] and not keys[pygame.K_w] and not keys[pygame.K_a] and not keys[pygame.K_d]:
            self.walk_dir = 'none'
    
        if self.walk_dir == 'none':
            self.image = self.afk
        else:
            self.walk(self.walk_dir)
            
        if self.collide_right:
            if keys[pygame.K_z]:
                self.walk('up')  
            if keys[pygame.K_s]:
                self.walk('down')  
                
        if self.collide_left:
            if keys[pygame.K_z]:
                self.walk('up')  
            if self.walk_dir == 'left' and keys[pygame.K_s]:
                self.walk('down')  
                
        if self.collide_up:
            if keys[pygame.K_d]:
                self.walk('right')        
            if keys[pygame.K_q]:
                self.walk('left')  
                
        if self.collide_down:
            if keys[pygame.K_d]:
                self.walk('right')  
            if keys[pygame.K_q]:
                self.walk('left')  
                
                
                
    def crit_rate(self):
        import random
        iscrit = random.randint(0,100)
        issupercrit = random.randint(0,100)
        
        if iscrit <= 10:
            self.crit = 1
            self.knockback = 4
            
        elif issupercrit < 5 :
            self.crit = 2 
            self.knockback = 8
            
        else:
            self.crit = 0         
            self.knockback = 2
            
    def fire_bullet(self):
        #permet au joueur de tirer des projectiles 
        self.bullet_knockback = self.knockback
        keys = pygame.key.get_pressed() 
        if self.fire_count > bulletrate:
            self.fire_count = 0 
            
        if self.hitCount +1 >= self.framemax: # pareil que pour frameCount, on utilise un nouveau compteur pour ne pas aditioner les deux (si on tire et se deplace en meme temps) 
            self.hitCount = 0
        
        if self.rider == False and self.charging == False: # de sorte a ce que l'on ne puisse pas tirer en velo.
            if keys[pygame.K_LEFT]:
                self.fire_count += 1  * self.game.time_multiplier
                self.hitCount += self.frametime  #augmente le compteur 
                self.afk = L2 #change la direction dans laquelle le joueur regarde si il arrete de tirer.
                self.dir = 'left'
                if self.mana >= self.shoot_manacost: #si le compteur fireCount est egal a bulletrate (valeur globale), et qu'il a suffisament de mana, il tire. Cela sert a regler la cadence de tir.               
                    self.image = (runLeft[int(self.hitCount)//self.framespeed]) #change l'animation        
                    self.shooting = True
                    if self.fire_count == bulletrate:
                        self.lostmana += self.shoot_manacost #Tirer coute de la mana.
                        Bullet(self.game, self.rect.left -32, self.rect.centery - 16, -bulletspeed, 0 , self.bullet_damage, self.crit, self.bullet_knockback) #Bullet a 4 parametres (x, y, velx, vely) x, et y sont sa position initiale et velx et vely sont sa vitesse sur les deux axes.
                        #fait apparaitre la sprite du projectile au bon endroit par rapport au joueur, 
                        #avec la bonne direction. (-bulletspeed pour aller a gauche, +bulletspeed pour aller a droite) VOIR class Bullet 
                        bulletfx.play()                                        
                    
            elif keys[pygame.K_RIGHT]: #pareil qu'au dessus en ajustant position et vitesse
                self.fire_count += 1  * self.game.time_multiplier
                self.hitCount += self.frametime
                self.afk = R2
                self.dir = 'right'                
                if self.mana >= self.shoot_manacost:  
                    self.image = (runRight[int(self.hitCount)//self.framespeed])     
                    self.shooting = True
                    if self.fire_count == bulletrate:
                        self.lostmana += self.shoot_manacost                    
                        Bullet(self.game, self.rect.right -32, self.rect.centery - 16, bulletspeed, 0 , self.bullet_damage, self.crit, self.bullet_knockback)
                        bulletfx.play()
           
            elif keys[pygame.K_UP]: #pareil qu'au dessus en ajustant position et vitesse
                self.fire_count += 1  * self.game.time_multiplier
                self.hitCount += self.frametime
                self.afk = U2
                self.dir = 'up'                
                if self.mana >= self.shoot_manacost:   
                    self.image = (runUp[int(self.hitCount)//self.framespeed])  
                    self.shooting = True
                    if self.fire_count == bulletrate:
                        self.lostmana += self.shoot_manacost
                        Bullet(self.game, self.rect.centerx -32, self.rect.top -32, 0, -bulletspeed , self.bullet_damage, self.crit, self.bullet_knockback)
                        bulletfx.play()

            
            elif keys[pygame.K_DOWN]: #pareil qu'au dessus en ajustant position et vitesse
                self.fire_count += 1  * self.game.time_multiplier
                self.hitCount += self.frametime
                self.afk = D2
                self.dir = 'down'                
                if self.mana >= self.shoot_manacost: 
                    self.image = (runDown[int(self.hitCount)//self.framespeed])    
                    self.shooting = True
                    if self.fire_count == bulletrate:
                        self.lostmana += self.shoot_manacost                    
                        Bullet(self.game, self.rect.centerx -32, self.rect.bottom -32, 0, bulletspeed , self.bullet_damage, self.crit, self.bullet_knockback)
                        bulletfx.play()
            else:
                if self.fire_count != bulletrate - 1:
                    self.fire_count += 1
                self.shooting = False
    def blur(self):
        #if self.running:
            #self.blur_count += 1
            #if self.blur_count >= 3:
                #self.blur_count = 0        
                #Speed_blur(self.game, self, 150, 10)
                
        if self.charging:
            self.blur_count += 1
            if self.blur_count >= 2:
                self.blur_count = 0
                Speed_blur(self.game, self, 75, 5)
            
    def update(self):
        #ici on appelle toutes les fonctions dans le bon ordre pour les actualiser 
        spawn_player_stats(self) #fait apparaitre les stat du joueur  
        self.frametime = 1 * self.game.time_multiplier        
        self.blur()
        self.death()
        self.dirty = 1       
        light_shader(self, 1)
        self.pos = vec(self.rect.center)
        if self.game.player_freeze == False:
            self.level_up()
            self.playerspeed = (4 + self.run + self. velo)  * self.game.time_multiplier
            self.controls()
            self.crit_rate() 
            if not self.charging:
                self.freemove()         
            self.charge()
            self.x += self.velx
            self.y += self.vely
            self.hitbox.x = self.x #velx s'ajoute a self.x, et self.rect.x etant egal a self.x. Donc si velx monte, le joueur bouge.
            self.rect.x = self.hitbox.x   
            collide_with_walls(self, self.game.walls, 'x', 'player') #collision du joueur avec le groupe voulu (les murs)        
            self.hitbox.y = self.y
            self.rect.bottom = self.hitbox.bottom            
            collide_with_walls(self, self.game.walls, 'y', 'player') #pareil sur l'axe y      
            self.collide_ladder()
            self.collidevelo()
            self.stats_regen()
            self.money()
            
            if self.game.peacefull == False:
                self.fire_bullet()
                self.cast_shield()




class Wall(pygame.sprite.Sprite):
    def __init__(self, game, x, y, w, h):
        #la sprite du mur, elle est invisible et sa taille est modulaire 
        self.groups = game.walls
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pygame.Rect(x, y, w, h)
        self.rect.topleft = (x, y) 
       

class Flower(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        #sprite cosmetique, une fleur 
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.frameCount = 0
        self.frameSpeed = 12
        self.frameMax = 60     
        self.image = flowerafk
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)  

    def update(self):
        hide(self, 24)
        self.frameCount += 1 * self.game.time_multiplier
        if self.frameCount >= self.frameMax:
            self.frameCount = 0
        self.image = (flowerTile[int(self.frameCount)//self.frameSpeed])
        self.dirty = 1

class Bush(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        #La sprite des buissons.
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.frameCount = 0
        self.image = bushafk
        self.shaking = False # verifie si le buisson est en train d'etre secoue.
        self.shaked = False # verifie si le buisson a deja ete secoue.
        self.ifspawn = 0 #sera une valeur aleatoire entre 0 et 10
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y) 
        self.x = x
        self.y = y
    def bushshake(self):
        collide = pygame.sprite.spritecollide(self, self.game.players, False) #si le joueur touche le buisson: 
        if collide and self.shaked == False: # si le buisson n'a pas ete secoue, alors est secoue 
            self.shaking = True
        if self.shaking == True and self.shaked == False: #si il est secoue, le compteur de son animation va monter 
            self.frameCount += 2  * self.game.time_multiplier
        if self.frameCount + 2  * self.game.time_multiplier >= 60: #quand il arrive a 60:
            import random
            for x in range(1):
                self.ifspawn = random.randint(0,10) #une valeur aleatoire entre 0 et 10 lui est attribue.        
            self.frameCount = 11 #l'image du buisson devient statique (deuxieme image de la liste)
            self.shaking = False #le buisson n'est plus secoue 
            self.shaked = True #le buisson a ete secoue 
        if not collide and self.frameCount == 11: #si le joueur sors du buisson, tout revient a 0, et il est pret a etre secoue encore une fois
            self.shaked = False
            self.frameCount = 0 

        if self.ifspawn == 1: #si la valeur aleatoire (attribuee quand il est secoue) est egale a 1, un mystherbe apparait.
            Mystherbe(self.game, self.x -64 , self.y -64)
            mystherbecri.play()
            self.ifspawn = 0 #la valeur aleatoire redevient fixe, de sorte a ce que les Mystherbes n'apparaissent pas continuellement.



    def update(self):
        self.bushshake()
        self.image = (bushshake[int(self.frameCount)//10])        
        self.dirty = 1
        hide(self, 24)
        




class Falltop(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        #sprite cosmetique, le haut de la cascade 
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.frameCount = 0
        self.frameSpeed = 15
        self.frameMax = 60     
        self.image = falltopafk
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)   
        
    def update(self):
        self.frameCount += 2 * self.game.time_multiplier
        if self.frameCount + 2  * self.game.time_multiplier >= self.frameMax:
            self.frameCount = 0
        self.image = (falltopTile[int(self.frameCount)//self.frameSpeed])
        self.dirty = 1

class Waterfall(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        #sprite cosmetique, c'est la cascade  
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.frameCount = 0
        self.frameSpeed = 15
        self.frameMax = 60     
        self.image = fallafk
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)     
        
    def update(self):
        self.frameCount += 2 * self.game.time_multiplier
        if self.frameCount + 2 * self.game.time_multiplier >= self.frameMax:
            self.frameCount = 0
        self.image = (fallTile[int(self.frameCount)//self.frameSpeed])
        self.dirty = 1

class Darkrai(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        #Le boss final, une sprite relativement complexe 
        self.groups = game.all_sprites, game.mobs
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.image = darkraiafk
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
#animation ----------------------------
        self.frameCount = 0
        self.frameSpeed = 30
        self.frameMax = 60 
        self.frame_multiplier = 1 #la vitesse a laquelle le compteur frameCount va monter 
        self.imageup = darkraiup 
        self.imagedown = darkraidown   
        self.darkraiimage = self.imagedown
#deplacement ------------------------
        self.vel = 4 # valeur de la vitesse de base de darkrai 
        self.velx = 0 # sa vitesse sur l'axe x
        self.vely = 0 # sa vitesse sur l'axe y
        self.triggered = False #dit au jeu si darkrai est actif 
        self.triggerrange = pygame.Rect(0, 0, 500, 500) #la zone dans laquelle il faut rentrer pour rendre darkrai actif 
        self.hitbox = pygame.Rect (0, 0, 34, 32) #la hitbox de darkrai (les projectiles doivent toucher ce rectangle la pour le blesser)
        self.x = x 
        self.y = y      
        self.fire_count = 0 #compteur qui sert a savoir si darkrai peut tirer 
#stats-----------------------------------
        self.losthealth = 0 
        self.health = 500 - self.losthealth
        self.spread = 0 # cette valeur sera aleatoire, elle permettra aux projectiles de darkrai d'aller dans une direction aleatoire.
        self.spreadrange = 5 #plus cette valeur augmente, moins les projectiles sont precis. 
        self.firerate = dark_bulletrate #la cadence de tir de base de darkrai. (dark_bulletrate est une valeur globale) 
        self.mob_spawn_count = 0 #compteur qui permettera de savoir quand faire apparaitre des mysthebes
        self.spawnstats = 0 #permettra de faire apparaitre sa barre de vie. 
        self.sound_count = 499 #compteur qui nous dit quand darkrai va crier, il est a 499 de base pour qu'il crie des le debut.
#knockback-------------------------------
        self.knockback = 0
        self.knockback_dir = 'none' 
        self.count = 0
    def trigger (self):
        #si le joueur touche le rectangle triggerrange, darkrai se met a attaquer
        self.triggerrange.center = self.rect.center 
        collide = self.game.player.rect.colliderect(self.triggerrange) 
        if collide: 
            self.triggered = True 
            
        if self.triggered == True:
            self.frame_multiplier  = 5  * self.game.time_multiplier #il s'anime plus vite lorsqu'il est actif (triggered)
            self.sound_count += 1 # tant qu'il est actif, il poussera des cris a chaque fois que le compteur atteindra 500.
            if self.sound_count == 500: 
                darkraicri.play()
                self.sound_count = 0
        else:
            self.frame_multiplier  = 1  * self.game.time_multiplier #il s'anime plus lentement
            
    def spawn_mob(self):
        #quand il est actif, darkrai fait apparaitre des Mystherbes autour de lui toutes les 240 frames. 
        self.mob_spawn_count += 1 * self.game.time_multiplier
        if self.mob_spawn_count == 240:
            Mystherbe(self.game, self.rect.right + 128  , self.rect.y)
            Mystherbe(self.game, self.rect.left - 128 , self.rect.y )
            Mystherbe(self.game, self.rect.x  , self.rect.bottom + 128 )
            Mystherbe(self.game, self.rect.x  , self.rect.top - 128 )
            self.mob_spawn_count = 0

    def collide_bullets(self):
        self.hitbox.center = self.rect.center #ajuste la position de la hitbox
        for bullet in self.game.bullets: 
            collide = self.hitbox.colliderect(bullet.hitbox) #si darkrai touche un projectile, son animation accelere
                
            if collide:
                self.frame_multiplier = 2


    def shootspread(self):
        import random
        self.spread = random.random() * self.spreadrange #self.spread devient un nombre aleatoire qui change constamment. 
        
    def animation(self):
        self.frameCount += self.frame_multiplier * self.game.time_multiplier
        if self.frameCount + self.frame_multiplier  * self.game.time_multiplier >= self.frameMax:
            self.frameCount = 0
        self.image = (self.darkraiimage[int(self.frameCount)//self.frameSpeed])
        self.dirty = 1    




        
    def intelligence(self):
        #en fonction d'ou darkrai se trouve par rapport au joueur, sa direction va changer.
        #il se deplacera toujours vers le joueur.
        if self.rect.centerx > self.game.player.rect.centerx:
            self.velx = -self.vel  #sa vitesse sur l'axe x change.
            self.left = True #permet au jeu de savoir dans quelle direction va darkrai (pour le moment cela n'est pas utile)
        else: 
            self.left = False

        if self.rect.centerx < self.game.player.rect.centerx:
            self.velx = self.vel
            self.right = True
        else:
            self.right = False 

        if self.rect.centery > self.game.player.rect.centery:
            self.vely = -self.vel #sa vitesse sur l'axe y change. 
            self.darkraiimage = darkraiup
            self.up = True
        else:
            self.up = False

        if self.rect.centery < self.game.player.rect.centery:
            self.vely = self.vel
            self.darkraiimage = darkraidown

            self.down = True
        else:
            self.down = False

        if self.rect.centerx == self.game.player.rect.centerx: #si darkrai est exactement sur le joueur, sa vitesse tombe a 0, cela evite un bug qui le faisait trembler. 
            self.velx = 0
        if self.rect.centery == self.game.player.rect.centery:
            self.darkraiimage = darkraidown
            self.vely = 0

        if self.rect.centery < self.game.player.rect.centery and self.rect.centerx == self.game.player.rect.centerx:  #en fonction d'ou il se trouve par rapport au joueur, darkrai regardera vers le haut ou vers le bas.
            self.darkraiimage = darkraidown 
        if self.rect.centery > self.game.player.rect.centery and self.rect.centerx == self.game.player.rect.centerx:   
            self.darkraiimage = darkraiup  
            
    def shoot(self):
        #avec �a, darkrai tire constamment dans toutes les directions.
        self.fire_count += 1 * self.game.time_multiplier
        if self.fire_count >= self.firerate:
            self.fire_count = 0 
            Dark_Bullet(self.game, self.rect.x + 32 , self.rect.bottom, -self.spreadrange / 2 + self.spread, dark_bulletspeed) #dark_bullet a 4 parametres (x, y, velx, vely)
            Dark_Bullet(self.game, self.rect.x + 32 , self.rect.top, -self.spreadrange / 2 + self.spread, -dark_bulletspeed) #on donne une vitesse fixe sur le bon axe et une vitesse aleatoire sur l'autre
            Dark_Bullet(self.game, self.rect.left , self.rect.y +32, -dark_bulletspeed, -self.spreadrange / 2 + self.spread) #de sorte a ce que les projectiles de darkrai se dispersent. 
            Dark_Bullet(self.game, self.rect.right , self.rect.y +32 , dark_bulletspeed, -self.spreadrange / 2 + self.spread)
                
        
    def death(self): 
        #quand sa vie tombe a 0, il meurt.
        #quand il meurt, il laisse derriere lui un warp (wilderness) qui vous ramene a la maison ainsi qu'une animation de portail (PortalSprite)

        self.health = 500 - self.losthealth        
        if self.health <= 0:
            self.game.boss_defeated = True
            self.game.player_xp += 1000
            self.game.player_copper_coins += 1000
            self.kill()
            self.game.target.shake_duration = 20
            self.game.music.stop()
            Warp(self.game, self.rect.centerx - 26, self.rect.centery + 16, 32, 4, 'home')
            Portalsprite (self.game, self.rect.centerx - 111, self.rect.centery - 50)
            self.game.all_sprites.move_to_front(self.game.player)
            super_critical_hit_fx.play()
        if self.health <= 250:
            self.vel = 6  * self.game.time_multiplier
            self.spreadrange = 10
            self.firerate = 5 #quand il a moins de la moitiee de sa vie, darkrai va plus vite, tire plus vite, et ses projectiles se dispersent encore plus.
        else: 
            self.vel = 4  * self.game.time_multiplier
            
    def controlled (self):
        keys = pygame.key.get_pressed()
        self.velx = 0
        self.vely = 0
        if keys[pygame.K_8]:
            self.vely = -self.vel
        if keys[pygame.K_2]:
            self.vely = self.vel        
        if keys[pygame.K_4]:
            self.velx = -self.vel
        if keys[pygame.K_6]:
            self.velx = self.vel
    def blur (self):
        self.count += 1
        if self.count >= 5:
            self.count = 0
            Speed_blur(self.game, self, 160, 20)
        
    def update(self):
        self.shootspread()    
        self.trigger()
        self.blur()
        if self.triggered == True: # darkrai ne tire pas et ne bouge pas tant qu'il n'est pas actif (triggered)
            if self.game.player_freeze == False:
                self.shoot()  
                knockback_def(self)
                #self.spawn_mob()
            else:
                self.velx = 0
                self.vely = 0
                
        spawn_mob_stats(self)
        self.collide_bullets()
        self.death()
        self.x += self.velx
        self.y += self.vely
        self.rect.x = self.x
        self.rect.y = self.y   
        self.animation()
class Ladder(pygame.sprite.Sprite):    
    def __init__(self, game, x, y, w, h):
        #sprite invisible, le joueur peut les grimper
        self.groups = game.ladder
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pygame.Rect(x, y, w, h)
        self.rect.topleft = (x, y) 
        
        
class Explosion(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        #sprite cosmetique, elle est jouee une fois des que un projectile touche un obstacle puis disparait.
        self.groups = game.all_sprites, game.bullets
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.image = bulletimg
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y) 
        self.hitbox = self.rect        
        self.game = game
        self.Count = 0
                   
    def update(self):
        self.hitbox = self.rect 
        self.image = (explode[int(self.Count)//10])
        self.Count += 2 * self.game.time_multiplier
        if self.Count +2 * self.game.time_multiplier >= 60:
            self.Count = 0
            self.kill()        
        
class Bullet(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y, velx, vely, damage, crit, knockback):
        #le projectile que tire le joueur
        self.groups = game.all_sprites, game.bullets
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.image = bulletimg
        self.rect = self.image.get_rect()
        self.pos = (x, y)
        self.rect.topleft = (x, y) 
        self.game = game
        self.damage = damage
        self.iscrit = crit  
        self.knockback = knockback
        self.homing = False
        self.growing = True  #cela indique que le projectile est en train de grandir  
        self.travelCount = 0 #compteur actif tant que le projectile grandit 
        self.frameCount = 0
        self.frameSpeed = 10
        self.frameMax = 60 
        self.x = x
        self.y = y
        self.hitbox = pygame.Rect(0, 0, 24, 24) #hitbox du projectile 
        self.velx = velx
        self.vely = vely
        self.vel = 10
        self.homing_vel = vec(x,y)
        self.acceleration = 1
        #shader------------------
        self.light = light_circle
        self.light = pygame.transform.scale(self.light, (self.light.get_width() * 1 , self.light.get_height() * 1))
        self.light_rect = self.light.get_rect()       
        self.blur_count = 0
        #----------------------
        
        if self.iscrit == 1:
            self.damage = self.damage * 2
        if self.iscrit == 2:
            self.damage = self.damage * 10   
    
    def blur(self):
        self.blur_count += 1
        if self.blur_count >= 3:
            self.blur_count = 0        
            Speed_blur(self.game, self, 100, 20)
            
    def is_homing(self):
        for mob in self.game.mobs:

            mob.pos = vec(mob.rect.center)
            self.rect.center = self.pos
            self.rot = (mob.pos - self.pos).angle_to(vec(1, 0))
            self.acc = vec(self.vel, 0).rotate(-self.rot)
            self.homing_vel += self.acc 
            self.pos = self.homing_vel 
            self.rect.center = self.pos
            pygame.transform.rotate(self.image, self.rot)
                                   
    def knockback_def(self):
        for sprite in self.game.mobs:       
            collide = self.hitbox.colliderect(sprite.hitbox)
            if collide:
                if self.velx > 0:
                    sprite.knockback_dir = 'right'
                    sprite.knockback = self.knockback
                if self.velx < 0:
                    sprite.knockback_dir = 'left'
                    sprite.knockback = self.knockback                
                if self.vely < 0:
                    sprite.knockback_dir = 'up'
                    sprite.knockback = self.knockback
                if self.vely > 0:
                    sprite.knockback_dir = 'down'
                    sprite.knockback = self.knockback   
                    
    def collide(self):
        #detecte les collisions avec les obstacles 
        self.hitbox.center = self.rect.center
        collidewall = pygame.sprite.spritecollide(self, self.game.walls, False)
        collidebullet = pygame.sprite.spritecollide(self, self.game.mob_bullets, False)
        
        for sprite in self.game.mobs:
            collidemob = self.hitbox.colliderect(sprite.hitbox)
            if collidemob:
                sprite.losthealth += self.damage #retire de la vie aux monstre touches 
                Explosion(self.game, self.rect.x, self.rect.y) #fait apparaitre une animation d'explosion
                Damage_img(self.game, sprite.rect.centerx, sprite.rect.y - 64, self.damage, sprite, 16, 2, 1, self.iscrit)
                
           
                
                self.kill() #disparait au contact d'un obstacle 
                
        if self.growing == True:
            self.travelCount += 2 * self.game.time_multiplier
            self.image = (travel[int(self.travelCount)//20]) #quand il grandit, le projectile a une animation 
        if self.travelCount + 2 >= 60:
            self.growing = False 
        if self.growing == False:
            self.image = bulletimg #quand il a finit de grandir, le projectile a une image fixe. 

        if collidewall:
            Explosion(self.game, self.rect.x, self.rect.y) #si il touche un mur, le projectile disparait et laisse derriere lui une explosion 
            self.kill()

        for sprite in collidebullet: # si un projectile du joueur touche un projectile ennemi, les deux disparaissent et laissent une explosion. 
            if collidebullet:
                #sprite.kill()
                #self.kill()
                #Dark_Explosion(sprite.game, sprite.rect.x, sprite.rect.y)
                #Explosion(self.game, self.rect.x, self.rect.y)
                pass 
            
    def update(self):
        if self.game.player_freeze == False:
            self.collide()
            self.knockback_def()
            self.x += self.velx * self.game.time_multiplier 
            self.y += self.vely * self.game.time_multiplier
            self.rect.x = self.x
            self.rect.y = self.y
            if self.homing == True:        
                self.is_homing() 
class Dark_Bullet(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y, velx, vely):
        # Ce projectile est exactement le m�me que celui du joueur, mais avec une autre animation 
        # il est utilise par les monstres et fait 30 degats.
        self.groups = game.all_sprites, game.mob_bullets
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.image = dark_bulletimg
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y) 
        self.game = game
        self.growing = True         
        self.travelCount = 0
        self.frameCount = 0
        self.frameSpeed = 10
        self.frameMax = 60 
        self.x = x
        self.y = y
        self.velx = velx
        self.vely= vely

    def collide(self):
        collidewall = pygame.sprite.spritecollide(self, self.game.walls, False)
        collideplayer = pygame.sprite.spritecollide(self, self.game.players, False)

        if self.growing == True:

            self.travelCount += 2 * self.game.time_multiplier
            self.image = (dark_bullet_travel[int(self.travelCount) //20]) 
        if self.travelCount + 2>= 60:
            self.growing = False 
        if self.growing == False:
            self.image = dark_bulletimg

        if collidewall or collideplayer:
            Dark_Explosion(self.game, self.rect.x, self.rect.y)
            self.kill()
        if collideplayer:
            for sprite in collideplayer:
                if sprite.shielded == False and sprite.charging == False:
                    sprite.losthealth += 30
                    
    def update(self):
        self.collide()
        self.x += self.velx * self.game.time_multiplier
        self.y += self.vely * self.game.time_multiplier
        self.rect.x = self.x
        self.rect.y = self.y
        
class Dark_Explosion(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        #sprite cosmetique creee quand un projectile ennemi disparait. 
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.image = dark_bulletimg
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y) 
        self.game = game
        self.Count = 0

    def animate (self):
        self.image = (dark_bullet_explode[int(self.Count)//10])
        self.Count += 2 * self.game.time_multiplier
        if self.Count +2 * self.game.time_multiplier >= 60:
            self.Count = 0
            self.kill()
            
    def update(self):
        self.animate()



class Warp(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y, w, h, destination):
        #sprite invisible qui change la carte du jeu.
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.image = vide
        self.game = game
        self.destination = destination
        self.toggle = 'home'  #la nouvelle carte depend de cette valeur. 
        self.rect = pygame.Rect(x, y, w, h)
        self.rect.topleft = (x, y) 

    def warp(self):
        for player in self.game.players:
            collide = self.rect.colliderect(player.hitbox)        
            if collide:
                self.game.fadeout(1024, 576)
                self.game.music.stop()
                
                if self.game.level == 'home':
                    if self.destination == 'starter zone':
                        self.game.player_location = 1
                        self.game.player_direction = walkDown[1]
                
                if self.game.level == 'starter zone':
                    if self.destination == 'home':
                        self.game.player_location = 2
                        self.game.player_direction = walkUp[1]    
                    if self.destination == 'starter cave':
                        self.game.player_location = 1
                        self.game.player_direction = walkUp[1]     
                        
                if self.game.level == 'starter cave':
                    if self.destination == 'starter zone':
                        self.game.player_location = 2
                        self.game.player_direction = walkDown[1]
                    if self.destination == 'way out':
                        self.game.player_location = 1
                        self.game.player_direction = walkUp[1]
                
                if self.game.level == 'way out':
                    if self.destination == 'starter cave':
                        self.game.player_location = 2
                        self.game.player_direction = walkDown[1]
                    if self.destination == 'balconi':
                        self.game.player_location = 1
                        self.game.player_direction = walkRight[1]
                
                if self.game.level == 'balconi':
                    if self.destination == 'way out':
                        self.game.player_location = 2
                        self.game.player_direction = walkDown[1]                       
                    if self.destination == 'boss room':
                        self.game.player_location = 1
                        self.game.player_direction = walkUp[1]  
                        
                if self.game.level == 'boss room':
                        if self.destination == 'home':
                            self.game.player_location = 1
                            self.game.player_direction = walkDown[1]                       

                self.game.level = self.destination
                
                for sprite in self.game.all_sprites:
                    sprite.kill()
                for sprite in self.game.hud:
                    sprite.kill()
                self.game.playing =False

    def update(self):
        self.warp()




class Mystherbe(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        #la derniere des trois sprites "vivantes" 
        self.groups = game.all_sprites, game.mobs
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.image = mystherbeafk
        self.rect = self.image.get_rect()
        self.pos = (x, y) 
        
#animation------------------------------------------------------
        self.Count = 0
        self.Countspeed = 20
        self.framespeed = 3        
        self.imageup = mystherbeup
        self.imagedown = mystherbedown
        self.imageleft = mystherbeleft
        self.imageright = mystherberight
        self.imageupleft = mystherbeupleft
        self.imageupright = mystherbeupright
        self.imagedownleft = mystherbedownleft
        self.imagedownright = mystherbedownright  
        self.mystherbeimage = mystherbedownright 
        self.afk = mystherbedown
        
#mouvement---------------------------------------------------
        self.homing_vel = (0,0)
        self.vel = 2 #vitesse de Mystherbe 
        self.velx = 0
        self.vely = 0
        self.x = x
        self.y = y        
        self.up = False
        self.down = True
        self.left = False
        self.right = False 
#statistiques-------------------------------------------
        self.losthealth = 0
        self.health = 500
        self.spawnstats = 0
        
#attaque-----------------------------------------------
        self.hitbox = pygame.Rect (0, 0, 40, 52)   
        self.firerate = 0 #compteur pour savoir si mystherbe peut attaquer       
        self.attack = Dark_Bullet(self.game, self.hitbox.x, self.hitbox.y, 0, 0) #l'attaque de mystherbe 
#knockback---------------------------------------------
        self.knockback = 0
        self.knockback_dir = 'none'
    
    def cast(self):
        for sprite in self.game.players:
            collide = self.hitbox.colliderect(sprite.rect) #collision entre la hitbox de mystherbe et celle du joueur 
            self.firerate += 1 * self.game.time_multiplier
            if collide and self.firerate == 5: #si il y a collision, mystherbe creer des projectiles blessant le joueur. 
                self.attack = Dark_Bullet(self.game, self.hitbox.x, self.hitbox.y, 0, 0)
            if self.firerate == 10:
                self.firerate = 0
                
    def death(self):
        import random
        self.health = 50 - self.losthealth
        if self.health <= 0:
            self.game.player_xp += 10 #le joueur gagne 10 xp si il est battu 
            self.kill()
            explodefx.play()
            self.game.target.shake_duration = 5
            self.game.player_copper_coins += random.randint(0,10)

    def gif(self):
        self.Count += self.framespeed * self.game.time_multiplier
        if self.Count + self.framespeed * self.game.time_multiplier >= 60:
            self.Count = 0
        self.image = (self.mystherbeimage[int(self.Count)//self.Countspeed])   
        
    def intelligence1(self):
        for player in self.game.players:

            player.pos = vec(player.rect.center)
            self.rot = (player.pos - self.pos).angle_to(vec(1, 0))
            self.acc = vec(self.vel, 0).rotate(-self.rot)
            self.homing_vel += self.acc 
            self.pos = self.homing_vel 
            self.rect.center = self.pos
            
    def intelligence(self):
        #meme systeme de deplacement que darkrai
        if self.rect.centerx > self.game.player.rect.centerx:
            self.velx = -self.vel
            self.left = True
        else: 
            self.left = False

        if self.rect.centerx < self.game.player.rect.centerx:
            self.velx = self.vel
            self.right = True
        else:
            self.right = False 

        if self.rect.centery > self.game.player.rect.centery:
            self.vely = -self.vel
            self.up = True
        else:
            self.up = False

        if self.rect.centery < self.game.player.rect.centery:
            self.vely = self.vel
            self.down = True
        else:
            self.down = False
        if self.rect.centerx == self.game.player.rect.centerx:   
            self.velx = 0
        if self.rect.centery == self.game.player.rect.centery:
            self.vely = 0

    def avoid (self):
        #non utilise, permet aux mystherbe de faire demi tour si ils se cognent entre eux (le resultat n'etait pas assez satisfaisant)
        for mob in self.game.mobs:
            collide = self.hitbox.colliderect(mob.hitbox)
            if collide:
                if mob != self:
                    self.velx = -mob.velx
                    self.vely = -mob.vely
                else: 
                    self.velx = self.velx
                    self.vely = self.vely
                    
    def animate(self):
        #des animations pour les 8 directions de mystherbe
        if self.up == True:
            if self.left == False and self.right == False:
                self.mystherbeimage = self.imageup

        if self.down == True:
            if self.left == False and self.right == False:
                self.mystherbeimage = self.imagedown             

        if self.left == True:
            if self.up == False and self.down == False:
                self.mystherbeimage = self.imageleft

        if self.right == True:
            if self.up == False and self.down == False:
                self.mystherbeimage = self.imageright

        if self.left == True and self.up == True:
            self.mystherbeimage = self.imageupleft       

        if self.right == True and self.up == True:
            self.mystherbeimage = self.imageupright

        if self.left == True and self.down == True:
            self.mystherbeimage = self.imagedownleft

        if self.right == True and self.down == True:
            self.mystherbeimage = self.imagedownright

    def update(self):   
        self.afk = self.mystherbeimage          
        if self.game.player_freeze == False:
            self.x += self.velx * self.game.time_multiplier
            self.y += self.vely * self.game.time_multiplier
            self.hitbox.x = self.x 
            self.rect.centerx = self.hitbox.centerx 
            collide_with_walls(self, self.game.walls, 'x', 'mob')        
            self.hitbox.y = self.y
            self.rect.centery = self.hitbox.centery 
            collide_with_walls(self, self.game.walls, 'y', 'mob')    
            self.cast()
        self.hitbox.center = self.rect.center           
        self.attack.rect.center = self.rect.center
        spawn_mob_stats(self)
        knockback_def(self)
        #self.avoid()

        self.death()
        self.gif()     
        self.animate() 
        self.dirty = 1
        self.hitbox.center = self.rect.center
        
        
class MobBar(pygame.sprite.DirtySprite):
    def __init__(self, game, sprite):
        #la barre de vie des monstres
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.image = pygame.Surface((sprite.health, 5 + 2))
        self.image.fill(0)        
        self.rect = self.image.get_rect()
        self.sprite = sprite


    def update(self):
        if self.sprite.health <= 0:
            self.kill()
        self.rect.centerx = self.sprite.rect.centerx + self.sprite.losthealth / 2 #permet de centrer la barre de vie quelque soit la vie du monstre. 
        self.rect.y = self.sprite.rect.y - 32
        self.length = abs(self.sprite.health) # la longueur de la barre de vie des monstres depend de leur vie, on met abs sinon sa longueur devient negative et le jeu plante. 
        self.image = pygame.Surface((self.length + 6, 5 + 6))
        self.image.fill(0)     
        self.dirty = 1

class MobHealth(pygame.sprite.DirtySprite):
    def __init__(self, game, sprite):
        #pareil que MobBar, mais vient s'afficher par dessus Mobbar, pour faire une barre de vie plus jolie. 
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.length = abs(sprite.health)        
        self.image = pygame.Surface((self.length, 5))
        self.image.fill(RED)       
        self.sprite = sprite        
        self.rect = self.image.get_rect()
        self.rect.centerx = self.sprite.rect.centerx + self.sprite.losthealth / 2 + 3
        self.rect.y = self.sprite.rect.y - 32 + 3        


    def update(self):
        if self.sprite.health <= 0:
            self.kill()        
        self.rect.centerx = self.sprite.rect.centerx + self.sprite.losthealth / 2 + 3
        self.rect.y = self.sprite.rect.y - 32 + 3
        self.length = abs(self.sprite.health)
        self.image = pygame.Surface((self.length, 5))
        self.image.fill(RED)     
        self.dirty = 1


class PlayerXP(pygame.sprite.DirtySprite):
    def __init__(self, game, sprite):
        self.groups = game.hud
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.image = pygame.Surface((sprite.health, 4))
        self.fillcolor = (0, 255, 132)
        self.rect = self.image.get_rect()
        self.sprite = sprite
        self.rect.x = 40
        self.rect.y = HEIGHT - 50 + 32
        self.game.hud.move_to_back(self)
        
    def level (self):        
        text_shadow = font_outline.render(str(int(self.sprite.level)) , False, (BLACK))
        text = font_text.render(str(int(self.sprite.level)) , False, (0, 255, 132))
        if self.game.menu_open == False:
        
            screen.blit(text_shadow,(self.rect.x +52 - 2 - text.get_width() / 2, self.rect.y - 4 - 2 ))        
            screen.blit(text_shadow,(self.rect.x +52 - text.get_width() / 2, self.rect.y - 4 - 2 ))        
            screen.blit(text_shadow,(self.rect.x +52 - 2 - text.get_width() / 2, self.rect.y - 4 ))        
            screen.blit(text_shadow,(self.rect.x +52 - text.get_width() / 2, self.rect.y - 4))            
            screen.blit(text,(self.rect.x +52 - text.get_width() / 2, self.rect.y - 4))
        

        
    def update(self):
        self.level()
        self.image.set_alpha(200)
        if self.sprite.level_xp != 0:
            self.length = 104 - (((self.sprite.next_level_xp - self.sprite.level_xp) - (self.sprite.xp - self.sprite.level_xp) ) / (self.sprite.next_level_xp - self.sprite.level_xp)) * 104
            if self.length >= 104:
                self.length = 104 
        else: 
            self.length = 0
        self.image = pygame.Surface((self.length, 4))
        self.image.fill(self.fillcolor)     
        self.dirty = 1
class PlayerHealth(pygame.sprite.DirtySprite):
    def __init__(self, game, sprite):
        #meme chose que MobHealth, cependant elle ne se centre pas et est utilise par le joueur. 
        self.groups = game.hud
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.image = pygame.Surface((sprite.health, 20))
        self.fillcolor = RED
        self.image.fill(self.fillcolor)        
        self.rect = self.image.get_rect()
        self.sprite = sprite
        self.rect.x = 20 + 28
        self.rect.y = HEIGHT - 50 + 8
        
    def update(self):
        self.length = abs(self.sprite.health / self.sprite.maxhealth) * 100 #avec cette ligne, la longueur de la barre ne monte pas (meme quand le joueur monte en niveau et gagne de la vie). 
        if self.sprite.health == 0:
            self.kill()
        self.image = pygame.Surface((self.length, 20))
        self.image.fill(self.fillcolor)     
        self.dirty = 1

class HealthBar(pygame.sprite.DirtySprite):
    #c'est le fond de la barre de vie du joueur, purement cosmetique. 
    def __init__(self, game, sprite):
        self.groups = game.hud
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.image = healthbarimg
        self.rect = self.image.get_rect()
        self.sprite = sprite
        self.rect.x =  20
        self.rect.y = HEIGHT - 50 
    def value(self):
        
        if self.game.menu_open == False:
            value = str(int(self.game.player.health))
            valuemax = str(int(self.game.player.maxhealth))
            
            text_shadow = font_text.render(value , True, (BLACK))
            screen.blit(text_shadow,(self.rect.x + 74 - text_shadow.get_width() + 2 , self.rect.y + 8 + 2 ))
            
            divide_shadow = font_text.render("/" , True, (BLACK))
            screen.blit(divide_shadow ,(self.rect.x + 76 + 2, self.rect.y + 8 + 2))
            
            textmax_shadow = font_text.render(valuemax , True, (BLACK))
            screen.blit(textmax_shadow,(self.rect.x + 90 + 2 , self.rect.y + 8 + 2 ))          
            
            text = font_text.render(value , True, (WHITE))
            screen.blit(text,(self.rect.x + 74 - text.get_width(), self.rect.y + 8 ))
            
            divide = font_text.render("/" , True, (WHITE))
            screen.blit(divide ,(self.rect.x + 76, self.rect.y + 8 ))
            
            textmax = font_text.render(valuemax , True, (WHITE))
            screen.blit(textmax,(self.rect.x + 90 , self.rect.y + 8 ))
        
  
        
        
    def update(self):
        self.value()
        if self.sprite.health == 0:
            self.kill()        
        self.dirty = 1

class ManaBar(pygame.sprite.DirtySprite):
    #pareil que HealthBar (pour la mana)
    def __init__(self, game, sprite):
        self.groups = game.hud
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.image = manabarimg
        self.rect = self.image.get_rect()
        self.sprite = sprite
        self.rect.x = 20
        self.rect.y = HEIGHT - 90 
        
    def value(self):
        
        if self.game.menu_open == False:
            value = str(int(self.game.player.mana))
            valuemax = str(int(self.game.player.maxmana))
            
            text_shadow = font_text.render(value , True, (BLACK))
            screen.blit(text_shadow,(self.rect.x + 74 - text_shadow.get_width() + 2 , self.rect.y + 8 + 2  ))
            
            divide_shadow = font_text.render("/" , True, (BLACK))
            screen.blit(divide_shadow ,(self.rect.x + 76 + 2 , self.rect.y + 8 + 2  ))
            
            textmax_shadow = font_text.render(valuemax , True, (BLACK))
            screen.blit(textmax_shadow,(self.rect.x + 90 + 2  , self.rect.y + 8 + 2  )) 
            
            text = font_text.render(value , True, (WHITE))
            screen.blit(text,(self.rect.x + 74 - text.get_width(), self.rect.y + 8 ))
            
            divide = font_text.render("/" , True, (WHITE))
            screen.blit(divide ,(self.rect.x + 76, self.rect.y + 8 ))
            
            textmax = font_text.render(valuemax , True, (WHITE))
            screen.blit(textmax,(self.rect.x + 90 , self.rect.y + 8 ))
        
    def update(self):
        self.value()
        if self.sprite.health == 0:
            self.kill()        
        self.dirty = 1
        
class PlayerMana(pygame.sprite.DirtySprite):
    #pareil que PlayerHealth (pour la mana)
    def __init__(self, game, sprite):
        self.groups = game.hud
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game 
        self.image = pygame.Surface((sprite.health, 28))
        self.fillcolor = GREEN
        self.image.fill(self.fillcolor)        
        self.rect = self.image.get_rect()
        self.sprite = sprite
        self.rect.x = 20 + 28
        self.rect.y = HEIGHT - 90 + 8 
        
    def update(self):
        self.length = (self.sprite.mana / self.sprite.maxmana) * 100 
        if self.sprite.mana <= 0:
            self.image = vide 
        else:
            self.image = pygame.Surface((self.length, 20))
        self.image.fill(LIGHTBLUE)     
        self.dirty = 1        

class Shield(pygame.sprite.DirtySprite):
    def __init__(self, game, sprite):
        #sprite du bouclier
        self.groups = game.all_sprites, game.bullets
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.image = shieldimg
        self.rect = self.image.get_rect()
        self.rect.x = sprite.rect.centerx - self.rect.width / 2 
        self.rect.y = sprite.rect.centery - self.rect.height / 2
        self.hitbox = self.image.get_rect()
        self.game = game
        self.Count = 1 
        self.sprite = sprite
        self.is_alive = True
        self.damage = 1 


    def aura (self):
        #inflige des degats continus si collision avec un monstre. 
        collide = pygame.sprite.spritecollide(self,self.game.mobs, False)
        for mob in collide:
            if collide:
                mob.losthealth += self.damage 
                Damage_img(self.game, mob.rect.centerx, mob.rect.y - 16, self.damage, mob , 16, 2, 5, False)
    def animate (self):
        #permet au bouclier de s'animer quand il arrete un projectile. 
        collide = pygame.sprite.spritecollide(self, self.game.mob_bullets, False)
        self.image = (shield[int(self.Count)//6])     
        if collide:
            self.Count += 6 * self.game.time_multiplier

        elif self.Count != 0:
            self.Count += 6
        else:
            self.Count = 0
            
        if self.Count +6 * self.game.time_multiplier >= 60:
            self.Count = 0 
            
    def toggle (self):
        #la variable utilisee par le joueur pour desactiver le bouclier 
        keys = pygame.key.get_pressed()
        if self.is_alive == False or not keys[pygame.K_SPACE]:
            self.kill()            

    def update(self):
        #self.aura()
        self.hitbox.center = self.rect.center
        self.toggle()
        self.animate()
        self.rect.x = self.sprite.rect.centerx - self.rect.width / 2 
        self.rect.y = self.sprite.rect.centery - self.rect.height / 2
        
class Speed_blur(pygame.sprite.DirtySprite):
    def __init__(self, game, sprite, alpha, decay_speed):
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.sprite = sprite
        self.image = vide
        self.sprite_image = sprite.image
        self.rect = self.image.get_rect()
        self.rect.topleft = sprite.rect.topleft 
        self.surface= pygame.Surface((200, 200))
        self.surface.fill(COLORKEY)   
        self.surface.set_colorkey(COLORKEY)
        self.alpha = alpha
        self.decay_speed = decay_speed
        self.game.all_sprites.move_to_back(self)
        self.count = 0
    def update(self):
        self.alpha -= self.decay_speed
        self.surface.blit(self.sprite_image, (0, 0))
        self.surface.set_alpha(self.alpha)
        self.image = self.surface 
        
        if self.alpha <= 0:
            self.kill()
        self.dirty = 1
        
class object_image(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y, image):
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = x, y
    def update(self):
        self.dirty = 1
        collide = pygame.sprite.spritecollide(self, self.game.players, False)
        if collide:
            self.game.all_sprites.move_to_front(self)
        else:
            self.game.all_sprites.move_to_back(self)
        

class Boug(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.walkRight = [pygame.image.load('ressources/images/sprites/boug/10.png').convert_alpha(), pygame.image.load('ressources/images/sprites/boug/11.png').convert_alpha(), pygame.image.load('ressources/images/sprites/boug/12.png').convert_alpha()]
        self.walkLeft = [pygame.image.load('ressources/images/sprites/boug/7.png').convert_alpha(), pygame.image.load('ressources/images/sprites/boug/8.png').convert_alpha(), pygame.image.load('ressources/images/sprites/boug/9.png').convert_alpha()]
        self.walkDown = [pygame.image.load('ressources/images/sprites/boug/1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/boug/2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/boug/3.png').convert_alpha()]
        self.walkUp = [pygame.image.load('ressources/images/sprites/boug/4.png').convert_alpha(), pygame.image.load('ressources/images/sprites/boug/5.png').convert_alpha(), pygame.image.load('ressources/images/sprites/boug/6.png').convert_alpha()]    
        self.image = self.walkDown[0]        
        self.rect = self.image.get_rect()
        self.rect.topleft = x, y        
        self.moving = False 
        self.framespeed = 2
        self.framespeed_new = self.framespeed 
        self.walkcount = 0
        self.dir = 'down'
        self.running = False
    def Keys(self):
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LSHIFT]:
            self.running = True
        else:
            self.running = False
        
        if keys[pygame.K_RIGHT]:
            self.dir = 'right'
            self.moving = True 
        elif keys[pygame.K_LEFT]:
            self.dir = 'left'
            self.moving = True 
        elif keys[pygame.K_UP]:
            self.dir = 'up'
            self.moving = True 
        elif keys[pygame.K_DOWN]:
            self.dir = 'down'
            self.moving = True 
        else:
            self.moving = False 
            
    def directions(self):
        
        if self.moving:
            self.walkcount += self.framespeed_new
            
            if self.walkcount + self.framespeed_new >= 60:
                self.framespeed_new = -self.framespeed 
                self.walkcount -= 20
            if self.walkcount <= 0:
                self.framespeed_new = self.framespeed
                self.walkcount += 20
                
            if self.dir == 'right':
                self.image = self.walkRight[self.walkcount//20]
                
            if self.dir == 'left':
                self.image = self.walkLeft[self.walkcount//20]  
                
            if self.dir == 'up':
                self.image = self.walkUp[self.walkcount//20]
        
            if self.dir == 'down':
                self.image = self.walkDown[self.walkcount//20]      
            
            if self.running:
                self.framespeed = 4 
            else:
                self.framespeed = 2
                
    def update(self):
        self.dirty = 1
        self.Keys()
        self.directions()
