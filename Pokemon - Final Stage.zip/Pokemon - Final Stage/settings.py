import pygame
from pygame.locals import *
from os import path
import pytmx

#couleurs
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
ORANGE = (255,210,0)
RED = (255, 0, 0)
PURPLE = (255, 0, 255)
WHITE = (255, 255, 255)
LIGHTGREY = (163, 163, 163)
DARKGREY = (50, 50 , 50)
LIGHTBLUE = (135,206,250)
COLORKEY = (53,10,255)
BEIGE = (240, 208, 136)
GOLD = (255, 222, 23)
SILVER = (185, 201, 194)
COPPER = (235, 177, 45)

#taille des cases, permet d'ajuster plus simplement la taille de la fenetre
TILESIZE = 64

#on multiplie par le nombre de cases voulue en largeur, hauteur, j'ai pris 16 et 9 car c'est le ratio de mon ecran. (pour le mode plein ecran)
WIDTH = TILESIZE * 16
HEIGHT = TILESIZE * 9
FPS = 60

#utilise pour le son 
pygame.mixer.pre_init(44100, -16, 1, 512)
pygame.mixer.init()
pygame.init() 

#screen est l'endroit ou on va dessiner toutes nos images/sprites/cartes 
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

#permet d'acceder aux fichiers du jeu pour charger images sons et cartes.
game_folder = path.dirname(__file__)
ressources_folder = path.join(game_folder, 'ressources')

#musiques 
theme1 = pygame.mixer.Sound('ressources/sounds/music/overworld.ogg')
theme1.set_volume(0.5)
theme2 = pygame.mixer.Sound('ressources/sounds/music/boss.ogg')
theme2.set_volume(0.5)
theme3 = pygame.mixer.Sound('ressources/sounds/music/home.ogg')
theme3.set_volume(0.5)
theme4 = pygame.mixer.Sound('ressources/sounds/music/water.ogg')
theme4.set_volume(0.5)
theme5 = pygame.mixer.Sound('ressources/sounds/music/cave.ogg')
theme5.set_volume(0.5)
theme6 = pygame.mixer.Sound('ressources/sounds/music/cave1.ogg')
theme6.set_volume(0.5)
#listes d'images pour quand on marche 
walkRight = [pygame.image.load('ressources/images/sprites/player/R1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/R2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/R3.png').convert_alpha()]
walkLeft = [pygame.image.load('ressources/images/sprites/player/L1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/L2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/L3.png').convert_alpha()]
walkUp = [pygame.image.load('ressources/images/sprites/player/U1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/U2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/U3.png').convert_alpha()]
walkDown = [pygame.image.load('ressources/images/sprites/player/D1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/D2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/D3.png').convert_alpha()]

#listes d'images pour quand on court
runRight = [pygame.image.load('ressources/images/sprites/player/RunR1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/RunR2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/RunR3.png').convert_alpha()]
runLeft = [pygame.image.load('ressources/images/sprites/player/RunL1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/RunL2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/RunL3.png').convert_alpha()]
runUp = [pygame.image.load('ressources/images/sprites/player/RunU1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/RunU2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/RunU3.png').convert_alpha()]
runDown = [pygame.image.load('ressources/images/sprites/player/RunD1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/RunD2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/RunD3.png').convert_alpha()]

#listes d'images pour quand on est sur le velo 
veloRight = [pygame.image.load('ressources/images/sprites/player/veloR1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/veloR2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/veloR3.png').convert_alpha()]
veloLeft = [pygame.image.load('ressources/images/sprites/player/veloL1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/veloL2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/veloL3.png').convert_alpha()]
veloUp = [pygame.image.load('ressources/images/sprites/player/veloU1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/veloU2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/veloU3.png').convert_alpha()]
veloDown = [pygame.image.load('ressources/images/sprites/player/veloD1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/veloD2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/player/veloD3.png').convert_alpha()]
veloD2 = pygame.image.load("ressources/images/sprites/player/veloD2.png").convert_alpha()
veloU2 = pygame.image.load("ressources/images/sprites/player/veloU2.png").convert_alpha()
veloL2 = pygame.image.load("ressources/images/sprites/player/veloL2.png").convert_alpha()
veloR2 = pygame.image.load("ressources/images/sprites/player/veloR2.png").convert_alpha()
velo = pygame.image.load('ressources/images/sprites/velo.png').convert_alpha()

#non utilise car coutait trop de performances, c'est une case d'eau comme on a sur la carte mais elle est constamment animee.
waterafk = pygame.image.load('ressources/images/sprites/water1.png').convert_alpha()
waterTile = [pygame.image.load('ressources/images/sprites/water1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/water2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/water3.png').convert_alpha(),
             pygame.image.load('ressources/images/sprites/water4.png').convert_alpha(), pygame.image.load('ressources/images/sprites/water6.png').convert_alpha(), pygame.image.load('ressources/images/sprites/water7.png').convert_alpha(),
             pygame.image.load('ressources/images/sprites/water8.png').convert_alpha()]

#images de la fleur 
flowerafk = pygame.image.load('ressources/images/sprites/flower1.png').convert_alpha()
flowerTile = [pygame.image.load('ressources/images/sprites/flower1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/flower2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/flower3.png').convert_alpha(),
             pygame.image.load('ressources/images/sprites/flower4.png').convert_alpha(), pygame.image.load('ressources/images/sprites/flower5.png').convert_alpha()]


#images du buisson 
bushafk = pygame.image.load('ressources/images/sprites/bush1.png').convert_alpha()
bushshake = [pygame.image.load('ressources/images/sprites/bush1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/bush2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/bush3.png').convert_alpha(), pygame.image.load('ressources/images/sprites/bush4.png').convert_alpha(), pygame.image.load('ressources/images/sprites/bush5.png').convert_alpha(), pygame.image.load('ressources/images/sprites/bush6.png').convert_alpha()]

#fall est la sprite de la cascade a droite de la carte.
#toptile est le haut de la cascade, qui est different.
falltopTile = [pygame.image.load('ressources/images/sprites/falltop1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/falltop2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/falltop3.png').convert_alpha(),
             pygame.image.load('ressources/images/sprites/falltop4.png').convert_alpha()]
falltopafk = pygame.image.load('ressources/images/sprites/falltop1.png').convert_alpha()
fallTile = [pygame.image.load('ressources/images/sprites/fall1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/fall2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/fall3.png').convert_alpha(),
             pygame.image.load('ressources/images/sprites/fall4.png').convert_alpha()]
fallafk = pygame.image.load('ressources/images/sprites/fall1.png').convert_alpha()

#listes des images de darkrai (pour les animations)
darkraidown = [pygame.image.load('ressources/images/sprites/darkrai1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/darkrai2.png').convert_alpha()]
darkraiup = [pygame.image.load('ressources/images/sprites/darkrai3.png').convert_alpha(), pygame.image.load('ressources/images/sprites/darkrai4.png').convert_alpha()]
darkraiafk = pygame.image.load('ressources/images/sprites/darkrai1.png').convert_alpha()
darkraihitdown = [pygame.image.load('ressources/images/sprites/vide.png').convert_alpha(), pygame.image.load('ressources/images/sprites/darkrai1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/darkrai2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/vide.png').convert_alpha()]
darkraihitup =[pygame.image.load('ressources/images/sprites/vide.png').convert_alpha(), pygame.image.load('ressources/images/sprites/darkrai3.png').convert_alpha(), pygame.image.load('ressources/images/sprites/darkrai4.png').convert_alpha(), pygame.image.load('ressources/images/sprites/vide.png').convert_alpha()]

#ces images sont utilisees quand le joueur arrete de se deplacer ou se cogne contre un mur. 
D2 = pygame.image.load("ressources/images/sprites/player/D2.png").convert_alpha() #regarde vers le bas
U2 = pygame.image.load("ressources/images/sprites/player/U2.png").convert_alpha() #regarde vers le haut
L2 = pygame.image.load("ressources/images/sprites/player/L2.png").convert_alpha() #regarde vers la gauche
R2 = pygame.image.load("ressources/images/sprites/player/R2.png").convert_alpha() #regarde vers la droite

#attaque (travel pour quand elle se deplace et explode quand elle touche un mur/sprite)
#Dark_bullet est le projectile utilise par les monstres.
travel = [pygame.image.load("ressources/images/sprites/bigball.png").convert_alpha(), pygame.image.load("ressources/images/sprites/bigball1.png").convert_alpha(), pygame.image.load("ressources/images/sprites/bigball2.png").convert_alpha()]
explode = [pygame.image.load('ressources/images/sprites/1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/3.png').convert_alpha(), pygame.image.load('ressources/images/sprites/4.png').convert_alpha(), 
           pygame.image.load('ressources/images/sprites/5.png').convert_alpha(), pygame.image.load('ressources/images/sprites/6.png').convert_alpha()]

dark_bullet_travel = [pygame.image.load("ressources/images/sprites/darkbigball.png").convert_alpha(), pygame.image.load("ressources/images/sprites/darkbigball1.png").convert_alpha(), pygame.image.load("ressources/images/sprites/darkbigball2.png").convert_alpha()]
dark_bullet_explode = [pygame.image.load('ressources/images/sprites/dark1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/dark2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/dark3.png').convert_alpha(), pygame.image.load('ressources/images/sprites/dark4.png').convert_alpha(), 
           pygame.image.load('ressources/images/sprites/dark5.png').convert_alpha(), pygame.image.load('ressources/images/sprites/dark6.png').convert_alpha()]

bulletimg = pygame.image.load("ressources/images/sprites/bigball2.png").convert_alpha() #image utilisee une fois que le projectile atteint sa taille maximale
bulletspeed = 15 #variable utilisee pour la vitesse a la quelle se deplacent les projectiles, l'augmenter accelere les projectiles.
bulletrate = 10 #variable utilisee pour la cadence a la quelle sont tires les projectiles la baisser accelere la cadence.

dark_bulletimg = pygame.image.load("ressources/images/sprites/darkbigball2.png").convert_alpha() #pareil ici pour les projectiles enemis.
dark_bulletrate = 10 
dark_bulletspeed = 10

#son
darkraicri = pygame.mixer.Sound('ressources/sounds/fx/darkrai.ogg')
darkraicri.set_volume(0.5)
levelup_sound = pygame.mixer.Sound('ressources/sounds/fx/levelup.ogg')
levelup_sound.set_volume(0.7)
mystherbecri = pygame.mixer.Sound('ressources/sounds/fx/mystherbe.ogg')
mystherbecri.set_volume(0.5)
dringvelo = pygame.mixer.Sound('ressources/sounds/fx/dringvelo.wav')
dringvelo.set_volume(1)
explodefx = pygame.mixer.Sound('ressources/sounds/fx/explode.wav')
explodefx.set_volume(1)
bulletfx = pygame.mixer.Sound('ressources/sounds/fx/hit.wav')
bulletfx.set_volume(0.8)
shieldfx = pygame.mixer.Sound('ressources/sounds/fx/shield.ogg')
shieldfx.set_volume(0.5)
critical_hit_fx = pygame.mixer.Sound('ressources/sounds/fx/critical_hit.wav')
critical_hit_fx.set_volume(0.7)
super_critical_hit_fx = pygame.mixer.Sound('ressources/sounds/fx/super_critical_hit.wav')
super_critical_hit_fx.set_volume(0.9)
open_menu_fx = pygame.mixer.Sound('ressources/sounds/fx/open_menu.wav')
open_menu_fx.set_volume(0.5)
select_fx = pygame.mixer.Sound('ressources/sounds/fx/select_beep.wav')
select_fx.set_volume(0.5)
dash_fx = pygame.mixer.Sound('ressources/sounds/fx/dash.ogg')
dash_fx.set_volume(0.2)
crash_fx = pygame.mixer.Sound('ressources/sounds/fx/crash.ogg')
crash_fx.set_volume(1)

# images du portail
portal_image = [pygame.image.load('ressources/images/sprites/portal1.png').convert_alpha(), pygame.image.load('ressources/images/sprites/portal2.png').convert_alpha(), pygame.image.load('ressources/images/sprites/portal3.png').convert_alpha()]
portalafk = pygame.image.load('ressources/images/sprites/portal1.png').convert_alpha()


#une surface recouvrant tout l'ecran dont on changera l'aplpha pour faire un effet fade in.
fade_in = pygame.Surface((WIDTH, HEIGHT))
fade_in.fill((0))
fade_in.set_alpha(0)

#images de mystherbe
mystherbeup = [pygame.image.load("ressources/images/sprites/mystherbe4.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe5.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe6.png").convert_alpha()]
mystherbedown = [pygame.image.load("ressources/images/sprites/mystherbe1.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe2.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe3.png").convert_alpha()]
mystherbeleft = [pygame.image.load("ressources/images/sprites/mystherbe7.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe8.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe9.png").convert_alpha()]
mystherberight = [pygame.image.load("ressources/images/sprites/mystherbe10.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe11.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe12.png").convert_alpha()]
mystherbeupleft = [pygame.image.load("ressources/images/sprites/mystherbe16.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe17.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe18.png").convert_alpha()]
mystherbeupright = [pygame.image.load("ressources/images/sprites/mystherbe22.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe23.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe24.png").convert_alpha()]
mystherbedownleft = [pygame.image.load("ressources/images/sprites/mystherbe13.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe14.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe15.png").convert_alpha()]
mystherbedownright = [pygame.image.load("ressources/images/sprites/mystherbe19.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe20.png").convert_alpha(), pygame.image.load("ressources/images/sprites/mystherbe21.png").convert_alpha()]
mystherbeafk = pygame.image.load("ressources/images/sprites/mystherbe9.png").convert_alpha()

#une liste d'images transparentes, utilisee pour faire clignoter darkrai quand il est touche.
videlist = [pygame.image.load("ressources/images/sprites/vide.png").convert_alpha(), pygame.image.load("ressources/images/sprites/vide.png").convert_alpha(), pygame.image.load("ressources/images/sprites/vide.png").convert_alpha(), pygame.image.load("ressources/images/sprites/vide.png").convert_alpha(), pygame.image.load("ressources/images/sprites/vide.png").convert_alpha(), pygame.image.load("ressources/images/sprites/vide.png").convert_alpha()]
vide = pygame.image.load('ressources/images/sprites/vide.png').convert_alpha()

#bouclier
shield = [pygame.image.load("ressources/images/sprites/shield1.png").convert_alpha(), pygame.image.load("ressources/images/sprites/shield2.png").convert_alpha(), pygame.image.load("ressources/images/sprites/shield3.png").convert_alpha(), pygame.image.load("ressources/images/sprites/shield4.png").convert_alpha(), pygame.image.load("ressources/images/sprites/shield5.png").convert_alpha(), pygame.image.load("ressources/images/sprites/shield6.png").convert_alpha(),
          pygame.image.load("ressources/images/sprites/shield7.png").convert_alpha(), pygame.image.load("ressources/images/sprites/shield8.png").convert_alpha(), pygame.image.load("ressources/images/sprites/shield9.png").convert_alpha(), pygame.image.load("ressources/images/sprites/shield10.png").convert_alpha()]
shieldimg = pygame.image.load("ressources/images/sprites/shield1.png").convert_alpha()

#barres de statistiques 
healthbarimg = pygame.image.load("ressources/images/hud/healthbar.png").convert_alpha()
manabarimg = pygame.image.load("ressources/images/hud/manabar.png").convert_alpha()

#polices
font_text = pygame.font.Font("resource1.tff", 12)
font_outline = pygame.font.Font("resource1.tff", 14)
#menu 
menu1 = pygame.image.load('ressources/images/hud/menu1.png').convert_alpha()
menu_stats = pygame.image.load('ressources/images/hud/menu_stats.png').convert_alpha()
arrow1 = pygame.image.load('ressources/images/hud/arrow.png').convert_alpha()
crosshair = pygame.image.load('ressources/images/hud/crosshair.png').convert_alpha()

#pieces
bronze_coin_img = pygame.image.load('ressources/images/hud/bronzecoin.png').convert_alpha()
silver_coin_img = pygame.image.load('ressources/images/hud/silvercoin.png').convert_alpha()
gold_coin_img = pygame.image.load('ressources/images/hud/goldcoin.png').convert_alpha()

#covers
bed_cover = pygame.image.load('ressources/images/covers/bed_cover.png').convert_alpha()

#shaders
light_circle = pygame.image.load('ressources/images/shaders/light_circle.png').convert_alpha()
